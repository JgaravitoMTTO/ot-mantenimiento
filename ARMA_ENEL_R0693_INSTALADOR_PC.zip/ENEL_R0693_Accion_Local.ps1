# A.R.D.A.N. ENEL R069.3 | Solo acciones locales explicitamente permitidas.
# No recibe argumentos del navegador, ni contrasenas en URL/Sheets/Drive.
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateSet('Clave','Manual','Activar','Deshabilitar','Estado')][string]$Accion,
      [switch]$DesdeNavegador)
$ErrorActionPreference='Stop'
$root='C:\ARMA_ENEL_R046'
$taskName='ARMA_ENEL_R065_DIARIO'
$vault=Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R046\secrets\enel_credencial.dpapi'
$state=Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R046\orquestador_r061\estado.json'
function Confirmar([string]$msg,[string]$palabra='SI') {
  $v=Read-Host ($msg+' Escriba '+$palabra)
  return $v -ceq $palabra
}
function ReporteEstado {
  $t=Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
  Write-Host ('Equipo: '+$env:COMPUTERNAME)
  Write-Host ('Usuario Windows: '+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
  Write-Host ('Core ENEL instalado: '+[bool](Test-Path -LiteralPath $root -PathType Container))
  Write-Host ('Credencial DPAPI propia: '+[bool](Test-Path -LiteralPath $vault -PathType Leaf))
  Write-Host ('Tarea ENEL: '+$(if($t){$t.State}else{'NO INSTALADA'}))
  if($t){
    $ti=Get-ScheduledTaskInfo -TaskName $taskName -ErrorAction SilentlyContinue
    if($ti){Write-Host ('Ultima ejecucion: '+$ti.LastRunTime+' | codigo Windows: '+$ti.LastTaskResult)}
    Write-Host ('Cuenta de tarea: '+$t.Principal.UserId+' | logon: '+$t.Principal.LogonType)
  }
  if(Test-Path -LiteralPath $state -PathType Leaf){
    try {$s=Get-Content -LiteralPath $state -Raw|ConvertFrom-Json;Write-Host ('Ultimo ciclo R061: '+$s.status+' | fecha UTC: '+$s.stamp)}
    catch {Write-Host 'Ultimo ciclo R061: ESTADO JSON NO INTERPRETABLE; verificar archivo local.'}
  }else{Write-Host 'Ultimo ciclo R061: NO REGISTRADO'}
  Write-Host 'Esta consulta LOCAL no garantiza recepcion en Sheets. Confirmar en panel ENEL.'
}
$exitCode=0
try {
  if($env:OS -ne 'Windows_NT'){throw 'SOLO_WINDOWS'}
  Write-Host 'A.R.M.A. | ENEL R069.3 | CONTROL LOCAL' -ForegroundColor Cyan
  ReporteEstado
  switch ($Accion) {
    'Estado' { break }
    'Clave' {
      if(-not(Confirmar 'Cambiaste ya la clave EN EL PORTAL OFICIAL y probaste el login?')){
        Write-Host 'CANCELADO: no se modifico DPAPI'; break
      }
      $helper=Join-Path $root 'ENEL_Guardar_Credenciales.ps1'
      if(!(Test-Path -LiteralPath $helper)){throw 'GUARDADOR_DPAPI_FALTANTE: instalar core R065'}
      if(Test-Path -LiteralPath $vault){
        $backup=Join-Path (Split-Path $vault -Parent) ('enel_antes_r0693_'+(Get-Date -Format yyyyMMdd_HHmmss)+'.dpapi.bak')
        Copy-Item -LiteralPath $vault -Destination $backup -ErrorAction Stop
        Write-Host 'Respaldo local cifrado creado (solo bajo esta identidad).'
      }
      & $helper
      if(-not $?) {throw 'GUARDADOR_DPAPI_FALLO'}
      if(!(Test-Path -LiteralPath $vault)){throw 'DPAPI_NO_CREADO'}
      Write-Host 'DPAPI ACTUALIZADO EN ESTE USUARIO. Ahora ejecutar descarga manual y comprobar Sheets.' -ForegroundColor Green
    }
    'Manual' {
      if(!(Test-Path -LiteralPath $vault)){throw 'CREDENCIAL_DPAPI_FALTANTE_EN_ESTA_CUENTA'}
      $verify=Join-Path $root 'ENEL_R061_Verificar_Ciclo.ps1'
      $cycle=Join-Path $root 'ENEL_R061_Ciclo_Automatico.ps1'
      if(!(Test-Path $verify) -or !(Test-Path $cycle)){throw 'CORE_R061_NO_INSTALADO'}
      if(-not(Confirmar 'Se verificara y ejecutara la descarga R061 completa en ESTE PC. Continuar?')){break}
      & powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $verify
      if($LASTEXITCODE -ne 0){throw ('VERIFICADOR_FALLO_'+$LASTEXITCODE)}
      & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $cycle
      if($LASTEXITCODE -ne 0){throw ('CICLO_FALLO_'+$LASTEXITCODE)}
      Write-Host 'CICLO LOCAL FINALIZADO: revisar aceptacion ENEL en Sheets.' -ForegroundColor Green
    }
    'Activar' {
      if(!(Test-Path -LiteralPath $vault)){throw 'CREDENCIAL_DPAPI_NO_PROVISIONADA'}
      if(!(Test-Path -LiteralPath $state)){throw 'FALTA_PRUEBA_MANUAL_R061_OK'}
      $j=Get-Content -LiteralPath $state -Raw|ConvertFrom-Json
      if([string]$j.status -cne 'OK'){throw 'ULTIMO_CICLO_MANUAL_NO_OK'}
      if([string]::IsNullOrWhiteSpace([string]$j.stamp)){throw 'SIN_FECHA_CICLO'}
      $age=([DateTime]::UtcNow-[DateTime]::Parse([string]$j.stamp).ToUniversalTime()).TotalDays
      if($age -lt 0 -or $age -gt 7){throw 'ULTIMO_OK_ANTERIOR_A_7_DIAS'}
      $t=Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
      if($t){
        $who=[Security.Principal.WindowsIdentity]::GetCurrent().Name
        if([string]$t.Principal.UserId -ine $who -and [string]$t.Principal.UserId -ine ($env:USERDOMAIN+'\'+$env:USERNAME)){
          throw 'TAREA_PERTENECE_A_OTRA_CUENTA_NO_MODIFICADA'
        }
        if(-not(Confirmar 'Habilitar la tarea ENEL existente en ESTE PC?')){break}
        Enable-ScheduledTask -TaskName $taskName -ErrorAction Stop | Out-Null
        Write-Host 'TAREA HABILITADA. Probar con Windows sin sesion abierta.' -ForegroundColor Green
      } else {
        $scheduler=Join-Path $root 'ENEL_R065_Programar_Diario.ps1'
        if(!(Test-Path -LiteralPath $scheduler)){throw 'INSTALADOR_PROGRAMADOR_R065_FALTANTE'}
        if(-not(Confirmar 'CREAR tarea diaria ENEL a las 03:30 en ESTE equipo con usuario Windows actual?' 'INSTALAR')){break}
        # R065 pregunta contrasena WINDOWS de forma oculta; necesaria para ejecucion sin sesion.
        & $scheduler -Hora '03:30' -Nombre $taskName -Habilitar
        if(-not $?) {throw 'PROGRAMADOR_R065_FALLO'}
        $t=Get-ScheduledTask -TaskName $taskName -ErrorAction Stop
        Write-Host ('TAREA REGISTRADA: '+$t.TaskName+' | '+$t.State) -ForegroundColor Green
      }
    }
    'Deshabilitar' {
      $t=Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
      if(-not $t){Write-Host 'SIN TAREA ENEL. No hay nada que deshabilitar.';break}
      if(-not(Confirmar 'DESHABILITAR la tarea diaria ENEL de ESTE PC? NO detiene un ciclo ya en curso.' 'DESHABILITAR')){break}
      Disable-ScheduledTask -TaskName $taskName -ErrorAction Stop | Out-Null
      Write-Host 'DESCARGA AUTOMATICA DESHABILITADA EN ESTE PC. Tarea preservada.' -ForegroundColor Yellow
    }
  }
  Write-Host ''; ReporteEstado
} catch {
  $exitCode=1
  Write-Host ('ERROR_CONTROL_R0693: '+$_.Exception.Message) -ForegroundColor Red
} finally {
  if($DesdeNavegador){[void](Read-Host 'Pulsa ENTER para cerrar')}
}
if($exitCode){exit $exitCode}
