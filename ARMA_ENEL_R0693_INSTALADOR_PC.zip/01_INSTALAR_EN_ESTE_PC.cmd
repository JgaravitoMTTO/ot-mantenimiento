@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo  A.R.M.A. ENEL R069.3 - INSTALACION EN ESTE PC
 echo  El usuario debera autorizar localmente. No es instalacion web silenciosa.
echo ============================================================
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0ENEL_R0693_Instalar_PC.ps1" -Instalar
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo INSTALACION NO CONFIRMADA. Codigo: %RC%
pause
exit /b %RC%
