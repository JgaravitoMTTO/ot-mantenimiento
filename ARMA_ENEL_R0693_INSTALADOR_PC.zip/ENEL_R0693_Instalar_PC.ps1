# A.R.D.A.N. ENEL R069.3 - instalacion EXCLUSIVAMENTE LOCAL.
# Puede descomprimirse en cualquier carpeta, detecta $PSScriptRoot.
# Nunca sobrescribe archivos de operacion existentes ni credenciales.
[CmdletBinding()]
param([switch]$Instalar,[switch]$Desinstalar,[switch]$Diagnostico)
$ErrorActionPreference='Stop'
if($env:OS -ne 'Windows_NT'){throw 'SOLO_WINDOWS'}
$root='C:\ARMA_ENEL_R046'
$appDir=Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R0693'
$runner='ENEL_R0693_Accion_Local.ps1'
$src=Join-Path $PSScriptRoot $runner
$dst=Join-Path $appDir $runner
$ps=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$actions=@{
 'arma-enel-r0693-clave'='Clave';
 'arma-enel-r0693-manual'='Manual';
 'arma-enel-r0693-activar'='Activar';
 'arma-enel-r0693-desactivar'='Deshabilitar';
 'arma-enel-r0693-estado'='Estado'
}
Write-Host 'A.R.M.A. | ENEL R069.3 | INSTALACION POR EQUIPO Y CUENTA'
Write-Host ('EQUIPO: '+$env:COMPUTERNAME)
Write-Host ('IDENTIDAD: '+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
Write-Host ('CARPETA ORIGEN EXTRAIDA: '+$PSScriptRoot)
Write-Host ('CORE EXISTE: '+[bool](Test-Path -LiteralPath $root -PathType Container))
Write-Host ('NODE DETECTADO: '+[bool](Get-Command node -ErrorAction SilentlyContinue))
Write-Host ('PYTHON DETECTADO: '+[bool](Get-Command python -ErrorAction SilentlyContinue))
foreach($k in ($actions.Keys|Sort-Object)){
  Write-Host ('PROTOCOLO '+$k+': '+[bool](Test-Path -LiteralPath ('HKCU:\Software\Classes\'+$k)))
}
if($Desinstalar){
  if((Read-Host 'Escriba RETIRAR para eliminar solo los 5 protocolos R069.3') -cne 'RETIRAR'){return}
  foreach($k in $actions.Keys){
    $reg='HKCU:\Software\Classes\'+$k
    if(Test-Path $reg){
      $commandKey=Join-Path $reg 'shell\open\command'
      $cmd=if(Test-Path $commandKey){[string](Get-Item $commandKey).GetValue('')}else{''}
      if($cmd.Contains('ENEL_R0693_Accion_Local.ps1')){Remove-Item -LiteralPath $reg -Recurse -Force}
    }
  }
  Write-Host 'REGISTROS R069.3 RETIRADOS. NO SE BORRAN CORE, DPAPI, HMAC NI TAREAS WINDOWS.'
  return
}
if(!$Instalar){Write-Host 'SOLO DIAGNOSTICO. Para instalar, ejecutar 01_INSTALAR_EN_ESTE_PC.cmd';return}
if(!(Test-Path -LiteralPath $src -PathType Leaf)){throw 'RUNNER_R0693_NO_EXISTE'}
if(!(Test-Path -LiteralPath $ps -PathType Leaf)){throw 'POWERSHELL_WINDOWS_5_1_NO_EXISTE'}
$ref=Join-Path $PSScriptRoot 'REFERENCIA_R065'
$hasPrivateCore = (Test-Path -LiteralPath (Join-Path $ref 'CORE') -PathType Container) -and
                  (Test-Path -LiteralPath (Join-Path $ref 'R065') -PathType Container)
if(-not $hasPrivateCore){
  Write-Host 'PAQUETE PUBLICO: se instala solo el PUENTE de los botones; el motor privado ENEL debe aprovisionarse aparte.' -ForegroundColor Yellow
}
foreach($k in $actions.Keys){
  $reg='HKCU:\Software\Classes\'+$k
  if(Test-Path $reg){throw ('PROTOCOLO_EXISTENTE_SIN_SOBRESCRIBIR_'+$k)}
}
if(Test-Path -LiteralPath $dst){
  if((Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash){
    throw 'AGENTE_EXISTENTE_DISTINTO: haga respaldo y desinstale antes de reemplazar'
  }
}
if((Read-Host 'Instalar core faltante y 5 botones en ESTA CUENTA WINDOWS? Escriba INSTALAR') -cne 'INSTALAR'){return}
# El paquete PUBLICO no crea C:\ARMA_ENEL_R046 ni copia codigo privado.
# El paquete PRIVADO aporta CORE R065 sin modificar archivos historicos existentes.
if($hasPrivateCore){
  New-Item -Path $root -ItemType Directory -Force | Out-Null
  foreach($dir in @('CORE','R065')) {
    foreach($f in Get-ChildItem -LiteralPath (Join-Path $ref $dir) -File){
      $target=Join-Path $root $f.Name
      if(!(Test-Path -LiteralPath $target -PathType Leaf)){
        Copy-Item -LiteralPath $f.FullName -Destination $target -ErrorAction Stop
        Write-Host ('COPIADO SOLO SI FALTABA: '+$f.Name)
      }else{Write-Host ('CONSERVADO SIN CAMBIOS: '+$f.Name)}
    }
  }
}
New-Item -Path $appDir -ItemType Directory -Force|Out-Null
Copy-Item -LiteralPath $src -Destination $dst -ErrorAction Stop
$done=@()
try{
 foreach($k in ($actions.Keys|Sort-Object)){
  $act=$actions[$k]
  $reg='HKCU:\Software\Classes\'+$k
  New-Item -Path $reg -Force|Out-Null
  $done+= $reg
  Set-Item -Path $reg -Value ('URL:ARMA ENEL R069.3 '+$act)
  New-ItemProperty -Path $reg -Name 'URL Protocol' -Value '' -PropertyType String -Force|Out-Null
  $commandKey=Join-Path $reg 'shell\open\command'
  New-Item -Path $commandKey -Force|Out-Null
  # Los parametros son FIJOS en Registro; no se transmite %1 desde la web.
  $cmd='"'+$ps+'" -NoProfile -ExecutionPolicy Bypass -File "'+$dst+'" -Accion '+$act+' -DesdeNavegador'
  Set-Item -Path $commandKey -Value $cmd
  if([string](Get-Item $commandKey).GetValue('') -cne $cmd){throw 'REGISTRO_NO_COINCIDE_'+$k}
  Write-Host ('REGISTRADO: '+$k)
 }
 Write-Host 'INSTALACION LOCAL COMPLETADA. Botones activos al abrir ARMA desde ESTA MISMA cuenta Windows.' -ForegroundColor Green
 Write-Host 'PENDIENTES por equipo: motor privado ENEL si falta, credencial DPAPI, HMAC, Node, Python y prueba manual R064.1.'
} catch {
 foreach($r in $done){if(Test-Path $r){Remove-Item -LiteralPath $r -Recurse -Force -ErrorAction SilentlyContinue}}
 throw
}
