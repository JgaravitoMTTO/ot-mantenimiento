﻿# ARMA R065: aprovisiona MISMA clave HMAC del receptor en otro perfil Windows.
# Leer clave solo desde vault corporativo autorizado; NO ChatGPT, mail ni Git.
# Se solicita oculta en esta consola y se cifra DPAPI CurrentUser.
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Security
$dir=Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R046\secrets'
$dest=Join-Path $dir 'enel_ingesta_r050.dpapi'
if(Test-Path $dest){throw 'HMAC_YA_EXISTE_EN_ESTA_CUENTA: NO SOBRESCRIBIR. Verificar identidad y entorno.'}
[IO.Directory]::CreateDirectory($dir)|Out-Null
$secret=Read-Host 'Clave HMAC hexadecimal de 64 caracteres desde vault corporativo (entrada oculta)' -AsSecureString
$ptr=[IntPtr]::Zero;$plain=$null;$bytes=$null;$enc=$null
try{
 $ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
 $plain=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
 if($plain -cnotmatch '^[a-f0-9]{64}$'){throw 'HMAC_FORMATO_INVALIDO: se requieren 64 hex minusculas.'}
 $bytes=[Text.Encoding]::UTF8.GetBytes($plain)
 $enc=[Security.Cryptography.ProtectedData]::Protect($bytes,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
 $tmp=Join-Path $dir ('enel_hmac_'+[Guid]::NewGuid().ToString('N')+'.tmp')
 [IO.File]::WriteAllBytes($tmp,$enc)
 Move-Item -LiteralPath $tmp -Destination $dest -ErrorAction Stop
 $acl=New-Object System.Security.AccessControl.FileSecurity
 $acl.SetAccessRuleProtection($true,$false)
 $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User
 $system=New-Object System.Security.Principal.SecurityIdentifier 'S-1-5-18'
 $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($sid,'FullControl','Allow')))
 $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($system,'FullControl','Allow')))
 [IO.File]::SetAccessControl($dest,$acl)
 Write-Host 'HMAC_APROVISIONADA_DPAPI_CURRENTUSER: no se modifico receptor Apps Script.'
}finally{
 if($ptr -ne [IntPtr]::Zero){[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)}
 if($bytes){[Array]::Clear($bytes,0,$bytes.Length)}
 if($enc){[Array]::Clear($enc,0,$enc.Length)}
 $plain=$null;$secret=$null
}
