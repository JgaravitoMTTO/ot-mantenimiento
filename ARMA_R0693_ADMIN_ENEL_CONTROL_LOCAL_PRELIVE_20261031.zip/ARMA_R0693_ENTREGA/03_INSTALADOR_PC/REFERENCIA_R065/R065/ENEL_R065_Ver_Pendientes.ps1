﻿# Consulta de solo lectura sobre la ultima ejecucion del agente.
$root=Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R046\orquestador_r065'
foreach($f in @('pendientes.json','ejecuciones.log')){
 $p=Join-Path $root $f
 if(Test-Path $p){Write-Host ('ARCHIVO: '+$p);Get-Content -LiteralPath $p -Tail 25}
 else{Write-Host ('NO DISPONIBLE: '+$p)}
}
