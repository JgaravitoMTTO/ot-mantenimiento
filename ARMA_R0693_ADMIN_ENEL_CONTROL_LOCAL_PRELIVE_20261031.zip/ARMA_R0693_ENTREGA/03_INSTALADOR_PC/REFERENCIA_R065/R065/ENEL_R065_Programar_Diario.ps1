﻿# Crear tarea SOLO tras ciclo manual OK. Cuenta Windows = misma cuenta DPAPI.
param([string]$Hora='03:30',[string]$Nombre='ARMA_ENEL_R065_DIARIO',[switch]$Habilitar)
$ErrorActionPreference='Stop'
if(!$Habilitar){throw 'MODO SEGURO: agregue -Habilitar despues de prueba manual OK.'}
if($Hora -notmatch '^([01]\d|2[0-3]):[0-5]\d$'){throw 'HORA_INVALIDA formato HH:mm'}
$root='C:\ARMA_ENEL_R046';$cycle=Join-Path $root 'ENEL_R065_Ejecutar_Silencioso.ps1'
if(!(Test-Path $cycle)){throw 'AGENTE_R065_NO_INSTALADO'}
$state=Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R046\orquestador_r061\estado.json'
if(!(Test-Path $state)){throw 'SIN_CICLO_MANUAL_PREVIO'}
$j=Get-Content -LiteralPath $state -Raw|ConvertFrom-Json
if($j.status -ne 'OK'){throw 'CICLO_MANUAL_NO_CONFIRMADO_OK'}
$who=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$sec=Read-Host ('Contrasena de Windows para la tarea programada bajo '+$who+' (NO ENEL)') -AsSecureString
$ptr=[IntPtr]::Zero;$plain=$null
try{
 $ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
 $plain=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
 $arg='-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+$cycle+'"'
 $action=New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $arg -WorkingDirectory $root
 $trigger=New-ScheduledTaskTrigger -Daily -At $Hora
 $settings=New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 1)
 Register-ScheduledTask -TaskName $Nombre -Action $action -Trigger $trigger -Settings $settings -User $who -Password $plain -Description 'ARMA ENEL diario headless; DPAPI bajo la cuenta del robot' -Force | Out-Null
 Write-Host ('TAREA_CREADA: '+$Nombre+' / '+$Hora+' (cuenta '+$who+'). Verificar historial Task Scheduler y primer dia.')
}finally{
 if($ptr -ne [IntPtr]::Zero){[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)}
 $plain=$null;$sec=$null
}
