﻿# ARMA ENEL R065 | ciclo AUTOMATICO SILENCIOSO. Tarea Programada utiliza cuenta DPAPI.
param([switch]$Simular)
$ErrorActionPreference='Stop'
$root='C:\ARMA_ENEL_R046'
$local=Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R046\orquestador_r065'
[IO.Directory]::CreateDirectory($local)|Out-Null
$log=Join-Path $local 'ejecuciones.log'
$pend=Join-Path $local 'pendientes.json'
$state=Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R046\orquestador_r061\estado.json'
$startedUtc=[DateTime]::UtcNow
function Report([string]$code,[string]$detail,[bool]$ok){
 $safe=($detail -replace '(?i)(password|token|clave\s*=)\s*[:=]\s*\S+','$1=[RESERVADO]')
 $o=[ordered]@{fechaUtc=[DateTime]::UtcNow.ToString('o');codigo=$code;detalle=$safe;servidor=$env:COMPUTERNAME;usuario=$env:USERNAME;requiereRevision=(-not $ok)}
 $o|ConvertTo-Json -Compress|Set-Content -LiteralPath $pend -Encoding UTF8
 ('{0} | {1} | {2}' -f $o.fechaUtc,$code,$safe)|Add-Content -LiteralPath $log -Encoding UTF8
}
try{
 if($Simular){Write-Host 'R065_SIMULACION_SIN_DESCARGA: sin modificar estado operativo.';exit 0}
 if(!(Test-Path (Join-Path $root 'ENEL_R061_Ciclo_Automatico.ps1'))){Report 'R065_FALTA_CICLO' 'Instalador incompleto' $false;exit 2}
 $std=Join-Path $local ('stdout_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.log')
 & powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $root 'ENEL_R061_Ciclo_Automatico.ps1') *> $std
 $code=$LASTEXITCODE
 $j=$null;if(Test-Path $state){try{$j=Get-Content -Raw -LiteralPath $state|ConvertFrom-Json}catch{}}
 $status=if($j){[string]$j.status}else{'SIN_ESTADO'}
 $fresh=$false; if($j -and $j.stamp){try{$fresh=([DateTime]::Parse([string]$j.stamp).ToUniversalTime() -ge $startedUtc.AddSeconds(-2))}catch{}}
 $detail=if($j){[string]$j.detail}else{'Consultar registro local sin credenciales'}
 if($code -eq 0 -and $status -eq 'OK' -and $fresh){
  Report 'R065_OK' 'Ciclo confirmado localmente; verificar corte Sheets' $true
  exit 0
 }
 $label=if($status -eq 'PENDIENTE_INTERVENCION'){'PENDIENTE_AUTENTICACION_MFA_O_DESCARGA'}
  elseif($status -eq 'PENDIENTE_CONCURRENCIA'){'PENDIENTE_CONCURRENCIA'}
  else{'PENDIENTE_REVISION_CICLO'}
 Report $label ($detail+' | salida local: '+$std) $false
 exit 1
}catch{
 Report 'R065_ERROR_EJECUCION' ([string]$_.Exception.Message) $false;exit 1
}
