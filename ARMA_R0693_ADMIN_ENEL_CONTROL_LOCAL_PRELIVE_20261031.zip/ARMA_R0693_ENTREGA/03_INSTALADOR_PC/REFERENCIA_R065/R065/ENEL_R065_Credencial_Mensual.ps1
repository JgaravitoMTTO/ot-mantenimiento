﻿# Revision mensual de credenciales, SIN REVELAR la clave. No ejecuta cambio automatico.
param([switch]$ActualizarCredencial)
$ErrorActionPreference='Stop'
$root='C:\ARMA_ENEL_R046'
$secret=Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R046\secrets\enel_credencial.dpapi'
if($ActualizarCredencial){
 if(!(Test-Path (Join-Path $root 'ENEL_Guardar_Credenciales.ps1'))){throw 'AYUDANTE_DPAPI_NO_EXISTE'}
 & (Join-Path $root 'ENEL_Guardar_Credenciales.ps1')
 if(-not $?){throw 'GUARDADO_CREDENCIAL_NO_CONFIRMADO'}
}
if(!(Test-Path $secret)){Write-Host 'PENDIENTE_CREDENCIAL_ENEL: DPAPI NO EXISTE EN ESTE PERFIL WINDOWS';exit 3}
$age=[int]((Get-Date)-(Get-Item $secret).LastWriteTime).TotalDays
if($age -ge 28){Write-Host ('REVISAR_ROTACION_ENEL: '+$age+' dias desde ultimo cambio local, confirmar vigencia en portal.')}
else{Write-Host ('CREDENCIAL_LOCAL_EXISTE: '+$age+' dias; no prueba autenticacion.')}
