﻿# A.R.D.A.N. R061 -- esquema mantiene arma-enel-r052 usado por Lecturas R059.
# Seguridad: NUNCA se intercala %1 (URI de terceros) en PowerShell.
# Solo usuario HKCU; respaldo .reg del registro ANTES de sobreescribir.
$ErrorActionPreference='Stop'
$handler='C:\ARMA_ENEL_R046\ENEL_R061_Accion_Local.ps1'
if(!(Test-Path -LiteralPath $handler)){throw 'ACCION_LOCAL_R061_FALTANTE'}
$backupDir=Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R046\backups_r061'
[IO.Directory]::CreateDirectory($backupDir)|Out-Null
$backup=Join-Path $backupDir ('arma-enel-r052_pre_r061_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.reg')
& reg.exe export 'HKCU\Software\Classes\arma-enel-r052' $backup /y *> $null
if($LASTEXITCODE -ne 0){Write-Host 'NO EXISTIA UN REGISTRO DE PROTOCOLO ANTERIOR (o no se pudo exportar); continuando.'}
$base='HKCU:\Software\Classes\arma-enel-r052'
New-Item -Path $base -Force|Out-Null
Set-Item -Path $base -Value 'URL:ARMA ENEL R061 (esquema R052)'
New-ItemProperty -Path $base -Name 'URL Protocol' -Value '' -PropertyType String -Force|Out-Null
$cmd=Join-Path $base 'shell\open\command'
New-Item -Path $cmd -Force|Out-Null
$ps="$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
Set-Item -Path $cmd -Value ('"{0}" -NoProfile -ExecutionPolicy Bypass -File "{1}"' -f $ps,$handler)
Write-Host 'ESQUEMA REGISTRADO: arma-enel-r052://actualizar bajo HKCU sin aceptar URI como parametro.'
Write-Host ('BACKUP REGISTRO SI EXISTIA: '+$backup)
