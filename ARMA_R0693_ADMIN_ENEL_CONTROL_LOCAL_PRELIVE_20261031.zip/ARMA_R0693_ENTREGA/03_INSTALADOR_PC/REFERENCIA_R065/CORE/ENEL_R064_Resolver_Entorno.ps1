# ARMA R064 - Detector de Node.js y Python 3.10+ para el mismo usuario Windows (DPAPI).
# No modifica PATH persistente, no instala software, no lee contrasenas.
# Configuracion OPCIONAL (si estan instalados fuera de rutas habituales):
# C:\ARMA_ENEL_R046\ENEL_R064_Runtime_Local.json
# {"nodeExe":"C:\\ruta\\node.exe","pythonExe":"C:\\ruta\\python.exe"}

function ARMA_R064_UniquePaths([object[]]$items) {
  $seen=@{}; $out=New-Object System.Collections.Generic.List[string]
  foreach($item in $items){
    $p=[string]$item
    if([string]::IsNullOrWhiteSpace($p)){continue}
    $p=[Environment]::ExpandEnvironmentVariables($p.Trim().Trim([char]34))
    if(!$p.EndsWith('.exe',[StringComparison]::OrdinalIgnoreCase)){continue}
    if(!$seen.ContainsKey($p.ToLowerInvariant())){$seen[$p.ToLowerInvariant()]=$true;[void]$out.Add($p)}
  }
  return @($out.ToArray())
}
function ARMA_R064_CheckExe([string]$path,[string]$kind,[string[]]$arguments) {
  if(!(Test-Path -LiteralPath $path -PathType Leaf)){return $null}
  try{
    $out=(& $path @arguments --version 2>$null | Out-String).Trim()
    if($LASTEXITCODE -ne 0){return $null}
    if($kind -eq 'node'){
      if($out -match '^v(\d+)\.(\d+)\.(\d+)'){return @{Exe=$path;Args=@($arguments);Version=$out}}
    }else{
      if($out -match '^Python (\d+)\.(\d+)'){
        $major=[int]$Matches[1];$minor=[int]$Matches[2]
        if($major -gt 3 -or ($major -eq 3 -and $minor -ge 10)){
          return @{Exe=$path;Args=@($arguments);Version=$out}
        }
      }
    }
  }catch{}
  return $null
}
function ARMA_R064_GetRuntime([string]$Root='C:\ARMA_ENEL_R046') {
  # Un URI externo nunca se usa como argumento. Todo se resuelve localmente.
  $machine=[Environment]::GetEnvironmentVariable('Path','Machine')
  $user=[Environment]::GetEnvironmentVariable('Path','User')
  $env:Path=(@($env:Path,$machine,$user) | Where-Object{$_}) -join ';'
  $nodeCandidates=@();$pythonCandidates=@();$launcherCandidates=@()
  $cfg=Join-Path $Root 'ENEL_R064_Runtime_Local.json'
  if(Test-Path -LiteralPath $cfg -PathType Leaf){
    try{
      $j=Get-Content -LiteralPath $cfg -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
      if($j.nodeExe){$nodeCandidates+=([string]$j.nodeExe)}
      if($j.pythonExe){$pythonCandidates+=([string]$j.pythonExe)}
    }catch{Write-Host 'R064_CONFIG_RUNTIME_JSON_INVALIDO';return $null}
  }
  foreach($c in @(Get-Command node.exe -All -ErrorAction SilentlyContinue)){
    if($c.CommandType -eq 'Application'){$nodeCandidates+=([string]$c.Source)}
  }
  foreach($c in @(Get-Command python.exe -All -ErrorAction SilentlyContinue)){
    if($c.CommandType -eq 'Application'){$pythonCandidates+=([string]$c.Source)}
  }
  foreach($c in @(Get-Command py.exe -All -ErrorAction SilentlyContinue)){
    if($c.CommandType -eq 'Application'){$launcherCandidates+=([string]$c.Source)}
  }
  foreach($base in @($env:ProgramW6432,$env:ProgramFiles,$env:LOCALAPPDATA,$env:APPDATA,$env:NVM_HOME,$env:NVM_SYMLINK,$Root)){
    if([string]::IsNullOrWhiteSpace($base)){continue}
    $nodeCandidates += @((Join-Path $base 'nodejs\node.exe'),(Join-Path $base 'node.exe'))
  }
  if($env:LOCALAPPDATA){
    $nodeCandidates += @(Join-Path $env:LOCALAPPDATA 'Programs\nodejs\node.exe')
    $launcherCandidates += @(Join-Path $env:LOCALAPPDATA 'Programs\Python\Launcher\py.exe')
    $pbase=Join-Path $env:LOCALAPPDATA 'Programs\Python'
    if(Test-Path -LiteralPath $pbase -PathType Container){
      foreach($d in @(Get-ChildItem -LiteralPath $pbase -Directory -ErrorAction SilentlyContinue)){
        if($d.Name -match '^Python3'){$pythonCandidates+=(Join-Path $d.FullName 'python.exe')}
      }
    }
  }
  foreach($base in @($env:ProgramFiles,$env:ProgramW6432)){
    if([string]::IsNullOrWhiteSpace($base)){continue}
    foreach($d in @(Get-ChildItem -LiteralPath $base -Directory -ErrorAction SilentlyContinue)){
      if($d.Name -match '^Python3'){$pythonCandidates+=(Join-Path $d.FullName 'python.exe')}
    }
  }
  if($env:NVM_HOME -and (Test-Path -LiteralPath $env:NVM_HOME -PathType Container)){
    foreach($d in @(Get-ChildItem -LiteralPath $env:NVM_HOME -Directory -ErrorAction SilentlyContinue)){
      if($d.Name -match '^v\d+'){$nodeCandidates+=(Join-Path $d.FullName 'node.exe')}
    }
  }
  $node=$null;$python=$null
  foreach($p in @(ARMA_R064_UniquePaths $nodeCandidates)){
    $node=ARMA_R064_CheckExe $p 'node' @()
    if($node){break}
  }
  foreach($p in @(ARMA_R064_UniquePaths $pythonCandidates)){
    $python=ARMA_R064_CheckExe $p 'python' @()
    if($python){break}
  }
  if(!$python){
    $launcherCandidates+=@('C:\Windows\py.exe')
    foreach($p in @(ARMA_R064_UniquePaths $launcherCandidates)){
      $python=ARMA_R064_CheckExe $p 'python' @('-3')
      if($python){break}
    }
  }
  if(!$node){Write-Host 'R064_FALTA_NODE: no se encontro node.exe operativo para este usuario.'}
  if(!$python){Write-Host 'R064_FALTA_PYTHON_310: no se encontro Python 3.10+ operativo para este usuario.'}
  if(!$node -or !$python){
    Write-Host ('USUARIO_WINDOWS='+[Environment]::UserName)
    Write-Host 'DIAGNOSTICO: pruebe where.exe node, node --version, where.exe python y py -0p.'
    Write-Host 'Si ya existen en otra carpeta, cree ENEL_R064_Runtime_Local.json con rutas absolutas; NO cambie claves ENEL.'
    return $null
  }
  Write-Host ('R064_NODE_OK '+$node.Version+' -> '+$node.Exe)
  Write-Host ('R064_PYTHON_OK '+$python.Version+' -> '+$python.Exe)
  return @{Node=[string]$node.Exe;Python=[string]$python.Exe;PythonArgs=@($python.Args)}
}
