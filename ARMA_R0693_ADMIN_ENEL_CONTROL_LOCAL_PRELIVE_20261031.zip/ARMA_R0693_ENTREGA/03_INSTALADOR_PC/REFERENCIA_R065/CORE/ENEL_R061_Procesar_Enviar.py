# -*- coding: utf-8 -*-
"""ARMA ENEL R061 (protocolo R050): XLSX ENEL -> lotes HMAC -> Google Apps Script aislado.
Solo libreria estandar Python 3.10+. Sin claves ni tokens en codigo/logs.
"""
import argparse, base64, datetime as dt, hashlib, hmac, json, os, re, sys, time
import urllib.request, urllib.error, xml.etree.ElementTree as ET, zipfile
from collections import defaultdict
from pathlib import Path

N = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
R = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
PR = '{http://schemas.openxmlformats.org/package/2006/relationships}'
MAP = {'Activa':'P','Reactiva Inductiva':'QI','Reactiva Capacitiva':'QC','Reactiva Inductiva Penalizada':'QPI'}
ACCOUNTS = ('11000090','11000232','11000412')

def fail(msg): raise RuntimeError(msg)
def text_cell(c,shared):
    typ=c.attrib.get('t',''); v=c.find(N+'v')
    if typ=='inlineStr': return ''.join(x.text or '' for x in c.findall('.//'+N+'t'))
    if v is None:return None
    s=v.text or ''
    if typ=='s':return shared[int(s)]
    return s

def parse_excel(filename):
    path=Path(filename)
    if not path.is_file() or path.stat().st_size>25*1024*1024:fail('ARCHIVO_NO_VALIDO_O_MUY_GRANDE')
    sha=hashlib.sha256(path.read_bytes()).hexdigest()
    with zipfile.ZipFile(path) as z:
        if len(z.infolist())>120 or sum(x.file_size for x in z.infolist())>100*1024*1024:fail('ZIP_EXCEDE_LIMITES')
        names=set(z.namelist())
        if 'xl/workbook.xml' not in names or 'xl/_rels/workbook.xml.rels' not in names:fail('NO_ES_XLSX')
        book=ET.fromstring(z.read('xl/workbook.xml'))
        rel=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        target={v.attrib['Id']:v.attrib['Target'] for v in rel.findall(PR+'Relationship')}
        sources={}
        for s in book.findall('.//'+N+'sheet'):
            name=s.attrib['name'];ref=target.get(s.attrib.get(R+'id'), '')
            ref=ref.lstrip('/') if ref.startswith('/') else 'xl/'+ref.lstrip('/') if not ref.startswith('xl/') else ref
            ref=os.path.normpath(ref).replace('\\','/')
            if not ref.startswith('xl/') or '/..' in ref:fail('RUTA_OOXML_INVALIDA')
            if name in MAP:sources[name]=ref
        if set(sources)!=set(MAP):fail('FALTAN_CUATRO_HOJAS')
        shared=[]
        if 'xl/sharedStrings.xml' in names:
            ss=ET.fromstring(z.read('xl/sharedStrings.xml'))
            shared=[''.join(x.text or '' for x in cell.findall('.//'+N+'t')) for cell in ss.findall(N+'si')]
        rows={}
        for sheet, mag in MAP.items():
            if sources[sheet] not in names:fail('HOJA_XLSX_NO_ENCONTRADA')
            root=ET.fromstring(z.read(sources[sheet]));d={}
            for row in root.findall('.//'+N+'sheetData/'+N+'row'):
                n=int(row.attrib.get('r','0'))
                if n<3:continue
                vals={}
                for cell in row.findall(N+'c'):
                    ref=cell.attrib.get('r','');match=re.match(r'([A-Z]+)',ref)
                    if not match:continue
                    col=0
                    for ch in match.group(1):col=col*26+ord(ch)-64
                    vals[col]=text_cell(cell,shared)
                if not any(v is not None for v in vals.values()):continue
                acct=str(vals.get(1,'')).split('.')[0].zfill(8)
                if acct not in ACCOUNTS:fail('CUENTA_INESPERADA')
                dayraw=str(vals.get(2,'')).strip(); try_date=None
                # ENEL puede exportar fecha como texto o serial OOXML de Excel.
                # La fecha debe identificarse sin cambiar el valor horario original.
                for fmt in ('%d/%m/%Y','%Y-%m-%d','%d/%m/%Y %H:%M:%S','%Y-%m-%d %H:%M:%S'):
                    try:
                        try_date=dt.datetime.strptime(dayraw,fmt).date();break
                    except ValueError:pass
                if try_date is None and re.fullmatch(r'\d+(?:\.\d+)?',dayraw):
                    serial=float(dayraw)
                    if 40000<=serial<=90000:
                        try_date=(dt.datetime(1899,12,30)+dt.timedelta(days=serial)).date()
                if try_date is None:fail('FECHA_NO_RECONOCIDA')
                day=try_date.isoformat();hours=[]
                for c in range(3,27):
                    s=vals.get(c)
                    if s in (None,''):fail('HORA_VACIA')
                    try:v=float(s.replace(',','.') if isinstance(s,str) else s)
                    except (ValueError,TypeError):fail('HORA_NO_NUMERICA')
                    if not 0<=v<1e8:fail('VALOR_FUERA_DE_RANGO')
                    hours.append(round(v,8))
                try:
                    val=vals.get(27)
                    declared=float(val.replace(',','.') if isinstance(val,str) else val)
                except (TypeError,ValueError): fail('TOTAL_FALTANTE')
                if abs(sum(hours)-declared)>max(0.08,abs(declared)*1e-6):fail('TOTAL_NO_CONCILIA')
                key=(acct,day)
                if key in d:fail('REGISTRO_DUPLICADO')
                d[key]=hours
            rows[mag]=d
    keys=set(rows['P']);
    if not keys or any(set(d)!=keys for d in rows.values()):fail('DIFERENCIA_DE_CUENTAS_O_FECHAS_ENTRE_HOJAS')
    dates=sorted({x[1] for x in keys})
    for day in dates:
        if {a for a,d in keys if d==day}!=set(ACCOUNTS):fail('FALTAN_TRES_CUENTAS')
    # Solo datos anteriores al dia local Bogota. El dia actual puede contener ceros de espera.
    bogota_now=dt.datetime.now(dt.timezone(dt.timedelta(hours=-5))).date().isoformat()
    closed=[day for day in dates if day<bogota_now]
    if not closed:fail('SIN_DIAS_CERRADOS')
    records=[]
    for day in closed:
        for acct in ACCOUNTS:
            records.append({'cuenta':acct,'dia':day,'horas':{m:rows[m][(acct,day)] for m in ('P','QI','QC','QPI')}})
    return sha, records, closed[-1], len(dates)-len(closed)

def secret_from_dpapi(script):
    import subprocess
    p=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',str(script)],
                     capture_output=True,text=True,check=False,timeout=15,encoding='utf-8',errors='replace')
    if p.returncode or not re.fullmatch('[a-f0-9]{64}',p.stdout.strip()):fail('CLAVE_INGESTA_DPAPI_NO_DISPONIBLE')
    return p.stdout.strip()

def post(url,secret,payload):
    import secrets
    ts=int(time.time()*1000);nonce=secrets.token_hex(16)
    b64=base64.b64encode(json.dumps(payload,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).decode()
    mac=hmac.new(secret.encode(),(str(ts)+'\n'+nonce+'\n'+b64).encode(),hashlib.sha256).hexdigest()
    envelope=json.dumps({'ts':ts,'nonce':nonce,'payloadB64':b64,'mac':mac},separators=(',',':')).encode()
    req=urllib.request.Request(url,data=envelope,headers={'Content-Type':'text/plain; charset=utf-8','User-Agent':'ARMA-ENEL-R050'},method='POST')
    try:
        with urllib.request.urlopen(req,timeout=110) as resp:
            if resp.status!=200:fail('HTTP_INESPERADO')
            raw=resp.read(12000)
    except (urllib.error.HTTPError,urllib.error.URLError,TimeoutError) as exc:
        fail('ERROR_TRANSPORTE_INGESTA_'+type(exc).__name__)
    try:r=json.loads(raw)
    except (ValueError,UnicodeDecodeError):fail('RESPUESTA_NO_JSON')
    if r.get('ok') is not True or r.get('accepted') is not True:fail('RECEPTOR_NO_ACEPTO_'+re.sub('[^A-Z0-9_]','',str(r.get('error','INDETERMINADO')))[:45])
    return r

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--manifest',required=True);ap.add_argument('--config',required=True);ap.add_argument('--dpapi',required=True);args=ap.parse_args()
    m=json.loads(Path(args.manifest).read_text(encoding='utf-8-sig'))
    if m.get('estado')!='XLSX_4_HOJAS_RECIBIDO_PENDIENTE_VALIDACION' or len(m.get('results',[]))!=1:fail('DESCARGA_R047_NO_VALIDADA')
    x=m['results'][0];file=Path(x['ubicacion']).resolve(strict=True)
    expected_dir=(Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'AppData'/'Local')))/'ARMA_ENEL_R046'/'descargas').resolve()
    if expected_dir not in file.parents:fail('FUERA_CARPETA_PRIVADA_DESCARGAS')
    if x.get('formato')!='XLSX_REAL' or file.suffix.lower()!='.xlsx':fail('ARCHIVO_NO_XLSX_REAL')
    config=json.loads(Path(args.config).read_text(encoding='utf-8-sig'))
    url=str(config.get('receiverUrl',''))
    from urllib.parse import urlparse
    u=urlparse(url)
    if u.scheme!='https' or u.hostname!='script.google.com' or not re.fullmatch(r'/macros/s/[A-Za-z0-9_-]+/exec',u.path) or u.query or u.fragment:
        fail('URL_RECEPTOR_NO_CONFIGURADA')
    sha,records,corte,skipped=parse_excel(file)
    if sha!=x.get('sha256'):fail('SHA256_DESCARGA_DISTINTO')
    secret=secret_from_dpapi(Path(args.dpapi))
    chunks=[];byday=defaultdict(list)
    for r in records:byday[r['dia']].append(r)
    days=sorted(byday)
    for off in range(0,len(days),7):
        sub=days[off:off+7]
        chunks.append((sub[0]+'_'+sub[-1],[r for d in sub for r in byday[d]]))
    accepted=0
    for cid,batch in chunks:
        # Reintento solo de fallos de transporte/receptor OCUPADO; max 2 intentos, mismo payload nuevo nonce.
        for attempt in range(2):
            try:
                result=post(url,secret,{'version':'R050','action':'chunk','sha256':sha,'chunk':cid,'items':batch})
                accepted+=len(batch)
                print('LOTE_OK',cid,'registros',len(batch),'modificados',result.get('modificados',0))
                break
            except RuntimeError as exc:
                if attempt or not any(t in str(exc) for t in ('ERROR_TRANSPORTE','OCUPADO')):raise
                time.sleep(5)
    fin=post(url,secret,{'version':'R050','action':'finalize','corte':corte,'sha256':sha})
    print('RESULTADO_R050_OK','filas_cuenta_dia',accepted,'parciales_omitidos',skipped,
          'corte_sheets',fin.get('corteValidado'),'corte_pendiente',bool(fin.get('pendiente')))
    if fin.get('pendiente'):fail('CORTE_PENDIENTE_DE_DATOS_COMPLETOS')
    if fin.get('resumenActualizado') is not True or fin.get('series')!=9:
        fail('RECEPTOR_R061_INCOMPATIBLE_O_RESUMEN_NO_ACTUALIZADO')
    return 0

if __name__=='__main__':
    try:sys.exit(main())
    except Exception as e:
        print('R050_PENDIENTE:',str(e)[:110],file=sys.stderr)
        sys.exit(1)
