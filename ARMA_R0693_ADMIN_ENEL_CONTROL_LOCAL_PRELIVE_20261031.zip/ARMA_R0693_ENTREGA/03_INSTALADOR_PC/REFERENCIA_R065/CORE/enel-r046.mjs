// A.R.D.A.N. / ARMA ENEL R047-WIN — corrección guiada por capturas Windows 25/10/2026.
// Destino en Windows: C:\ARMA_ENEL_R046\enel-r046.mjs
// Sintaxis: node --check .\enel-r046.mjs
// Prueba segura: node .\enel-r046.mjs --diagnostico
// Descargar rango mes anterior->actual EN UN SOLO ARCHIVO: node .\enel-r046.mjs --descargar
// NO conecta Google Sheets, no toca ARMA LIVE, R045 ni GitHub.
// NO utiliza #energia-capacitiva-tab ni #energia-capacitiva para navegar.

import { chromium } from 'playwright';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { inflateRawSync } from 'node:zlib';
import { createInterface } from 'node:readline/promises';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const ORIGIN = 'https://clientes-mnr.enel.com.co';
const BASE = `${ORIGIN}/excellencecol/`;
const LOGIN = `${BASE}#/login`;
const CONSUMOS = `${BASE}#/estadisticas_de_consumo`;
const SECRET_ROOT = path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'), 'ARMA_ENEL_R046');
const SECRET_FILE = path.join(SECRET_ROOT, 'secrets', 'enel_credencial.dpapi');
const HELPER_SAVE = path.join(ROOT, 'ENEL_Guardar_Credenciales.ps1');
const HELPER_READ = path.join(ROOT, 'ENEL_Leer_Credenciales.ps1');
const STAMP = new Date().toISOString().replace(/[:.]/g, '-');
const OUT = path.join(SECRET_ROOT, 'ejecuciones', STAMP);
const DOWNLOADS = path.join(SECRET_ROOT, 'descargas', STAMP);
const BROWSER_DOWNLOADS = path.join(OUT, '_chromium_temporal');
const FRONTIERS = ['Frt04172', 'Frt00625', 'Frt07938']; // Solo IDs de controles observados en Work R046; NO equivalencias R045.
const PARAMS = new Set(process.argv.slice(2));
const EXPORT = PARAMS.has('--descargar');
const DIAGNOSTIC = !EXPORT;
const UNATTENDED = PARAMS.has('--desatendido');
const INTERACTIVE = !UNATTENDED && Boolean(process.stdin.isTTY);
const CAPTURE = PARAMS.has('--captura'); // Captura OPCIONAL; puede contener datos comerciales privados.
const HOLD_MS = 8 * 60 * 1000;
const UI_TIMEOUT_MS = 180000; // SPA y módulos ENEL: hasta 3 min, esperando condiciones verificables.
const QUERY_TIMEOUT_MS = 180000;
const DOWNLOAD_TIMEOUT_MS = 180000;
const POLL_MS = 700;
const STABLE_MS = 2500;
function progreso(etapa, detalle) { console.log(`[R046-ESPERA] ${etapa}: ${detalle}`); }
async function esperarCondicion(etapa, test, timeoutMs = UI_TIMEOUT_MS, stableMs = STABLE_MS) {
  progreso(etapa, `comprobando condiciones (máximo ${Math.round(timeoutMs / 1000)} s)`);
  const end = Date.now() + timeoutMs;
  let stableSince = 0;
  let lastMessageAt = 0;
  while (Date.now() < end) {
    let ok = false;
    try { ok = Boolean(await test()); } catch { /* DOM SPA puede recrearse durante render */ }
    if (ok) {
      if (!stableSince) stableSince = Date.now();
      if (Date.now() - stableSince >= stableMs) {
        progreso(etapa, 'LISTO y estable');
        return;
      }
    } else stableSince = 0;
    if (Date.now() - lastMessageAt >= 15000) {
      progreso(etapa, 'aún cargando/verificando; no se avanza');
      lastMessageAt = Date.now();
    }
    await new Promise(resolve => setTimeout(resolve, POLL_MS));
  }
  stop(`TIMEOUT_${etapa}`, `No se confirmó estado estable de ${etapa} dentro del límite; no continuar a la siguiente etapa.`);
}
async function busyVisible(frame) {
  // Detectores genéricos. No leer valores de formularios ni contenido privado.
  return frame.locator('[aria-busy="true"]:visible,[role="progressbar"]:visible,.spinner-border:visible,.spinner-grow:visible,.loading:visible,.loader:visible,.swal2-loading:visible').count().then(n => n > 0).catch(() => false);
}
async function listoParaPeriodo(frame) {
  const start = frame.locator('#fechaI:visible');
  const end = frame.locator('#fechaF:visible');
  if (await start.count() !== 1 || await end.count() !== 1) return false;
  if (!(await start.isEnabled()) || !(await end.isEnabled())) return false;
  if (await busyVisible(frame)) return false;
  return true;
}

const allowedArgs = new Set(['--diagnostico', '--descargar', '--desatendido', '--captura']);
if (process.argv.slice(2).some(a => !allowedArgs.has(a)) || (PARAMS.has('--descargar') && PARAMS.has('--diagnostico'))) {
  console.error('Uso: node .\\enel-r046.mjs [--diagnostico | --descargar] [--desatendido] [--captura]');
  process.exit(2);
}
if (process.platform !== 'win32') {
  console.error('R046: DPAPI CurrentUser requiere Windows. No se intenta autenticación fuera de Windows.');
  process.exit(2);
}

function periodsBogota() {
  const p = new Intl.DateTimeFormat('en-US', { timeZone: 'America/Bogota', year: 'numeric', month: '2-digit' }).formatToParts(new Date());
  const year = Number(p.find(t => t.type === 'year').value);
  const month = Number(p.find(t => t.type === 'month').value);
  return [new Date(Date.UTC(year, month - 2, 1)), new Date(Date.UTC(year, month - 1, 1))].map(d =>
    `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`);
}
class StopSeguro extends Error {
  constructor(code, message) { super(message); this.name = 'StopSeguro'; this.code = code; }
}
function stop(code, msg) { throw new StopSeguro(code, msg); }
function estadoRuta(page) {
  try {
    const u = new URL(page.url());
    if (u.origin !== ORIGIN) return 'FUERA_ORIGEN_AUTORIZADO';
    const h = u.hash.toLowerCase();
    if (h.startsWith('#/login')) return 'LOGIN';
    if (h.startsWith('#/inicio')) return 'INICIO';
    if (h.startsWith('#/estadisticas_de_consumo')) return 'ESTADISTICAS_CONSUMO';
    return 'OTRA_RUTA_AUTORIZADA';
  } catch { return 'RUTA_NO_IDENTIFICADA'; }
}
function sitioAutorizado(page) {
  try { const u = new URL(page.url()); return u.origin === ORIGIN && u.pathname.startsWith('/excellencecol/'); }
  catch { return false; }
}
function frameAutorizado(frame) {
  try { return new URL(frame.url()).origin === ORIGIN; } catch { return false; }
}
function codigoDeError(e) {
  // NO persistir e.message de Playwright: potencialmente contiene URL, texto del DOM u otros secretos.
  return e instanceof StopSeguro ? { codigo: e.code, detalle: e.message } :
    { codigo: 'EXCEPCION_NO_CLASIFICADA', detalle: e && e.code ? String(e.code).slice(0, 32) : (e?.name || 'Error') };
}
async function existe(p) { return fs.access(p).then(() => true, () => false); }
function psRun(file, inherit = false) {
  return new Promise((resolve, reject) => {
    const child = spawn('powershell.exe', ['-NoLogo', '-NoProfile', ...(inherit ? [] : ['-NonInteractive']), '-ExecutionPolicy', 'Bypass', '-File', file], {
      windowsHide: !inherit,
      stdio: inherit ? ['inherit', 'inherit', 'inherit'] : ['ignore', 'pipe', 'pipe'],
      env: { ...process.env, ARMA_DPAPI_PIPE: inherit ? '0' : '1' }
    });
    let output = '';
    // stdout contiene credencial SOLO durante lectura DPAPI: nunca imprimir ni escribir a disco.
    if (!inherit) child.stdout.on('data', b => {
      output += b.toString('utf8');
      if (output.length > 16384) { child.kill(); reject(new Error('Puente DPAPI devolvió demasiados datos')); }
    });
    // stderr nunca se imprime: PowerShell podría mostrar información imprevista.
    if (!inherit) child.stderr.on('data', () => {});
    child.on('error', reject);
    child.on('close', code => code === 0 ? resolve(output) : reject(new Error(`Puente DPAPI finalizó código ${code}`)));
  });
}
async function pedirActualizacion() {
  if (!INTERACTIVE) return false;
  if (!(await existe(HELPER_SAVE))) stop('FALTA_ASISTENTE', 'No está instalado ENEL_Guardar_Credenciales.ps1.');
  console.log('Se abrirá el asistente local: usuario y clave NO se registran ni se envían a A.R.D.A.N.');
  try {
    await psRun(HELPER_SAVE, true);
    return await existe(SECRET_FILE);
  } catch { return false; }
}
async function leerCredencial() {
  if (!(await existe(HELPER_READ))) stop('FALTA_LECTOR_DPAPI', 'No está instalado ENEL_Leer_Credenciales.ps1.');
  if (!(await existe(SECRET_FILE))) {
    console.log('No hay secreto DPAPI local.');
    if (!(await pedirActualizacion())) stop('PENDIENTE_ACTUALIZAR_CREDENCIAL', 'Guardar credencial bajo el usuario Windows que ejecutará el robot.');
  }
  let output;
  try { output = await psRun(HELPER_READ); }
  catch { stop('PENDIENTE_CREDENCIAL_DPAPI', 'No se puede descifrar con este perfil Windows; ejecutar asistente con la misma cuenta.'); }
  try {
    const parsed = JSON.parse(output);
    if (typeof parsed.usuario !== 'string' || typeof parsed.password !== 'string' || !parsed.usuario || !parsed.password) throw Error('vacio');
    return parsed;
  } catch { stop('PENDIENTE_CREDENCIAL_DPAPI', 'Contenido DPAPI inválido; actualizar el secreto en Windows.'); }
}
async function visible(loc) { try { return (await loc.count()) === 1 && await loc.isVisible(); } catch { return false; } }
async function hayFormularioLogin(page) {
  try { return await page.locator('input[type="password"]:visible').count() > 0; }
  catch { return false; }
}
async function rechazoCredencialExplicito(page) {
  // Leer SOLO alertas visibles; no usar body.innerText, no guardar mensajes.
  const alerts = page.locator('[role="alert"],.alert-danger,.invalid-feedback,.toast-error,.swal2-validation-message,.text-danger');
  try {
    const n = Math.min(await alerts.count(), 16);
    for (let i = 0; i < n; i++) {
      const el = alerts.nth(i);
      if (!(await el.isVisible())) continue;
      const txt = (await el.innerText()).slice(0, 300);
      if (/((usuario|contraseñ|password|clave|credencial).{0,80}(incorrect|inválid|inval|erróne|no coincid|no válid|rechazad))|((incorrect|inválid|inval).{0,60}(usuario|contraseñ|password|credencial))/i.test(txt)) return true;
    }
  } catch { /* no es prueba de contraseña incorrecta */ }
  return false;
}
async function esperarSesion(page, timeoutMs) {
  const until = Date.now() + timeoutMs;
  while (Date.now() < until) {
    if (!sitioAutorizado(page)) return 'ORIGEN_INESPERADO';
    if (['INICIO', 'ESTADISTICAS_CONSUMO'].includes(estadoRuta(page)) && !(await hayFormularioLogin(page))) return 'OK';
    if (await rechazoCredencialExplicito(page)) return 'CLAVE_RECHAZADA';
    await page.waitForTimeout(900);
  }
  return 'NO_CONFIRMADA'; // Puede ser CAPTCHA/MFA, lentitud, bloqueo u otro fallo. No es clave incorrecta.
}
async function completarLogin(page, cred) {
  if (!sitioAutorizado(page)) stop('ORIGEN_INESPERADO', 'No introducir credenciales en un origen distinto de ENEL.');
  const password = page.locator('input[type="password"]:visible');
  if (await password.count() !== 1) return false;
  let usuario = null;
  const selectors = [
    'input[type="email"]:visible',
    'input[autocomplete="username"]:visible',
    'input[name="username"]:visible',
    'input[name="usuario"]:visible',
    'input[name="email"]:visible',
    'input[type="text"]:visible'
  ];
  for (const sel of selectors) {
    const candidate = page.locator(sel);
    if (await candidate.count() === 1) { usuario = candidate; break; }
  }
  if (!usuario) return false; // No adivinar formulario no observado.
  const btns = [
    page.getByRole('button', { name: /^(iniciar sesi[oó]n|ingresar|acceder|entrar)$/i }),
    page.locator('button[type="submit"]:visible'),
    page.locator('input[type="submit"]:visible')
  ];
  let boton = null;
  for (const b of btns) if (await visible(b)) { boton = b; break; }
  if (!boton) return false;
  await usuario.fill(cred.usuario);
  await password.fill(cred.password);
  // Borrar referencias cuanto antes en el llamador; Playwright no crea logs de valores.
  await boton.click({ timeout: 10000 });
  return true;
}
async function autenticar(page, manifest) {
  await page.goto(LOGIN, { waitUntil: 'domcontentloaded', timeout: 60000 });
  let outcome = await esperarSesion(page, 4000);
  if (outcome === 'OK') { manifest.auth = 'SESION_EXISTENTE'; return; }
  if (!sitioAutorizado(page)) stop('ORIGEN_INESPERADO', 'Portal fuera del origen ENEL.');
  let cred = await leerCredencial();
  try {
    if (await completarLogin(page, cred)) {
      cred = null;
      outcome = await esperarSesion(page, 90000);
    } else {
      cred = null;
      outcome = 'REQUIERE_LOGIN_MANUAL';
    }
  } finally { cred = null; }
  if (outcome === 'OK') { manifest.auth = 'AUTOMATICA_CONFIRMADA'; return; }
  if (outcome === 'CLAVE_RECHAZADA') {
    manifest.auth = 'RECHAZO_CREDENCIAL_EXPLICITO';
    console.log('El portal indicó explícitamente que la credencial es incorrecta. Máximo una renovación y un reintento.');
    if (!INTERACTIVE) stop('PENDIENTE_ACTUALIZAR_CREDENCIAL', 'Actualizar el secreto local; no reintentar desde Scheduler.');
    if (!(await pedirActualizacion())) stop('PENDIENTE_ACTUALIZAR_CREDENCIAL', 'Asistente cancelado.');
    await page.goto(LOGIN, { waitUntil: 'domcontentloaded', timeout: 60000 });
    let renovada = await leerCredencial();
    try {
      if (!(await completarLogin(page, renovada))) stop('PENDIENTE_INTERVENCION_AUTENTICACION', 'Formulario cambiado o requiere intervención.');
      renovada = null;
      outcome = await esperarSesion(page, 90000);
    } finally { renovada = null; }
    if (outcome === 'OK') { manifest.auth = 'RENOVADA_CONFIRMADA'; return; }
    if (outcome === 'CLAVE_RECHAZADA') stop('PENDIENTE_ACTUALIZAR_CREDENCIAL', 'Credencial renovada rechazada; verificar en portal, sin más reintentos.');
  }
  if (outcome === 'ORIGEN_INESPERADO') stop('ORIGEN_INESPERADO', 'Redirección fuera de ENEL.');
  if (!INTERACTIVE) stop('PENDIENTE_INTERVENCION_AUTENTICACION', 'Autenticación no confirmada; podría requerir MFA/CAPTCHA o revisión del formulario.');
  console.log('Autenticación no confirmada automáticamente. Complete en Chromium cualquier MFA/CAPTCHA o login legítimo pendiente (máximo 5 min).');
  const manual = await esperarSesion(page, 300000);
  if (manual !== 'OK') stop(manual === 'CLAVE_RECHAZADA' ? 'PENDIENTE_ACTUALIZAR_CREDENCIAL' : 'PENDIENTE_INTERVENCION_AUTENTICACION', 'No se confirmó acceso al área autenticada.');
  manifest.auth = 'INTERVENCION_HUMANA_CONFIRMADA';
}

// Observabilidad reducida: solo etiquetas conocidas. Nunca innerHTML, valores de inputs o URL completa.
async function diagnosticarInterfaz(page) {
  const frames = page.frames();
  const labels = [
    ['consumos_medidos', /consumos\s+medidos/i],
    ['energia_capacitiva', /energ[ií]a.*capacitiv/i],
    ['estadisticas_consumo', /estad[ií]sticas?\s+de\s+consumo/i],
    ['buscar_frontera', /buscar\s+por\s+frontera\s+comercial/i],
    ['descargar_consumos', /descargar\s+consumos/i]
  ];
  const resumen = [];
  for (const f of frames.slice(0, 12)) {
    try {
      const snapshot = await f.evaluate((labelsPlain) => {
        const ok = x => !!(x && x.getClientRects().length);
        const txt = x => String(x.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 90);
        const nodes = [...document.querySelectorAll('[role="tab"],a,button,[data-bs-toggle="tab"],[data-toggle="tab"]')].filter(ok).slice(0, 150);
        const known = [];
        for (const n of nodes) for (const item of labelsPlain) {
          if (new RegExp(item.re, 'i').test(txt(n))) {
            known.push({ etiqueta: item.key, activo: n.getAttribute('aria-selected') === 'true' || n.classList.contains('active') });
            break;
          }
        }
        return {
          documento: document.readyState,
          fechaI: !!document.querySelector('#fechaI') && ok(document.querySelector('#fechaI')),
          fechaF: !!document.querySelector('#fechaF') && ok(document.querySelector('#fechaF')),
          principal: !!document.querySelector('#principal'),
          totalCheckboxFrontera: document.querySelectorAll('input[type="checkbox"][value^="Frt"]').length,
          totalBotones: document.querySelectorAll('button').length,
          etiquetas: known.slice(0, 16)
        };
      }, labels.map(([key, re]) => ({ key, re: re.source })));
      resumen.push({ frame: resumen.length, ...snapshot });
    } catch { resumen.push({ frame: resumen.length, documento: 'NO_LEIBLE' }); }
  }
  return { ruta: estadoRuta(page), frames: frames.length, indicadores: resumen };
}
function tieneControles(f) {
  return f.locator('#fechaI:visible').count().then(n => n === 1).catch(() => false);
}
// El 25/10 la captura mostró «módulo ... no se encuentra disponible» en #/inicio.
// Ese aviso NO es un rechazo de contraseña. Puede desaparecer sin intervención.
async function avisoModuloNoDisponible(page) {
  try { return await page.getByText(/El m[oó]dulo al que intentas acceder no se encuentra disponible/i).first().isVisible(); }
  catch { return false; }
}
async function esperarAvisoInicial(page) {
  if (!(await avisoModuloNoDisponible(page))) return;
  progreso('AVISO_INICIO', 'modal informativo de módulo no disponible; no confundir con autenticación');
  await esperarCondicion('AVISO_INICIO_DESAPARECE', async () => !(await avisoModuloNoDisponible(page)), 90000, 1500);
}
async function seleccionarConsumos(page, diag) {
  await esperarAvisoInicial(page);
  progreso('NAVEGACION', 'URL de Consumos medidos confirmada por capturas; esperar SPA/controles');
  await page.goto(CONSUMOS, { waitUntil: 'domcontentloaded', timeout: 90000 });
  const deadline = Date.now() + UI_TIMEOUT_MS;
  let intentoNavegacionMenu = false;
  let ultimoAviso = 0;
  while (Date.now() < deadline) {
    if (!sitioAutorizado(page)) stop('ORIGEN_INESPERADO', 'Navegación fuera del portal autorizado.');
    if (await hayFormularioLogin(page)) stop('PENDIENTE_INTERVENCION_AUTENTICACION', 'Sesión requiere autenticación; no significa contraseña errónea.');
    // La UI puede regresar a inicio con un modal tras navegar muy temprano.
    if (estadoRuta(page) === 'INICIO' && await avisoModuloNoDisponible(page)) {
      await esperarAvisoInicial(page);
      if (!intentoNavegacionMenu) {
        intentoNavegacionMenu = true;
        progreso('REINTENTO_SEGURO', 'aviso cerrado; reabriendo ÚNICAMENTE URL comprobada de Consumos');
        await page.goto(CONSUMOS, { waitUntil: 'domcontentloaded', timeout: 90000 });
      }
    }
    for (const frame of page.frames()) {
      if (!frameAutorizado(frame)) continue;
      try {
        const hasForm = await listoParaPeriodo(frame);
        const labelVisible = await frame.getByText(/^\s*Consumos medidos\s*$/i).first().isVisible().catch(() => false);
        if (hasForm && labelVisible && estadoRuta(page) === 'ESTADISTICAS_CONSUMO') {
          // Está abierta la pestaña correcta. No hacer clic innecesario ni en energía capacitiva.
          const activeWrongTab = await frame.locator('[role="tab"].active,[role="tab"][aria-selected="true"],a.nav-link.active').evaluateAll(nodes =>
            nodes.some(n => /capacitiv/i.test(n.textContent || '') && !/consumos medidos/i.test(n.textContent || '')));
          if (activeWrongTab) stop('PANTALLA_CAPACITIVA_INCORRECTA', 'Pestaña capacitiva activa: no exportar.');
          await esperarCondicion('PANTALLA_CONSUMOS_MEDIDOS', async () =>
            estadoRuta(page) === 'ESTADISTICAS_CONSUMO' &&
            await listoParaPeriodo(frame) &&
            await frame.getByText(/^\s*Consumos medidos\s*$/i).first().isVisible(), UI_TIMEOUT_MS, 2200);
          diag.pantalla = 'CONSUMOS_MEDIDOS_CONFIRMADO';
          diag.frameControles = page.frames().indexOf(frame);
          diag.pagina = 'estadisticas_de_consumo';
          return frame;
        }
        // Si la pestaña visible no está activa, pulsar exactamente «Consumos medidos» una única vez.
        if (!hasForm && labelVisible && !diag.intentoActivacionPestana) {
          const exactTab = frame.getByRole('tab', { name: /^\s*Consumos medidos\s*$/i });
          const exactLink = frame.getByRole('link', { name: /^\s*Consumos medidos\s*$/i });
          const target = (await exactTab.count()) === 1 ? exactTab : (await exactLink.count()) === 1 ? exactLink : null;
          if (target && await target.isVisible()) {
            diag.intentoActivacionPestana = true;
            await target.click({ timeout: 12000 });
          }
        }
      } catch (e) { if (e instanceof StopSeguro) throw e; }
    }
    if (Date.now() - ultimoAviso > 15000) {
      progreso('SPA_CONSUMOS', `sin avanzar; ruta=${estadoRuta(page)}; esperando pestaña y fechas`);
      ultimoAviso = Date.now();
    }
    await page.waitForTimeout(1000);
  }
  diag.pantalla = 'NO_CONFIRMADA';
  stop('PENDIENTE_VERIFICAR_UI', 'No se confirmó en Chromium la pantalla Consumos medidos con fecha inicial/final.');
}

async function confirmarFronteras(frame) {
  const boxes = FRONTIERS.map(value => frame.locator(`input[type="checkbox"][value="${value}"]`));
  let presentes = (await Promise.all(boxes.map(b => b.count())));
  if (presentes.every(n => n === 1)) {
    for (const box of boxes) if (!(await box.isChecked())) await box.check({ force: true, timeout: 15000 });
    if (!(await Promise.all(boxes.map(b => b.isChecked()))).every(Boolean))
      stop('FRONTERAS_NO_SELECCIONADAS', 'No quedaron marcadas las tres fronteras.');
    return 'TRES_VALORES_PORTAL_VERIFICADOS';
  }
  // En la captura de ENEL el selector está plegado y muestra «Seleccionado 3/3».
  // Si la aplicación no expone checkboxes hasta desplegarlo, intentar desplegarlo.
  const selectorTexto = frame.getByText(/Buscar por frontera comercial\s*\(Seleccionado\s*3\s*\/\s*3\)/i).first();
  if (await selectorTexto.isVisible().catch(() => false)) {
    try { await selectorTexto.click({ timeout: 4000 }); } catch { /* puede ser texto dentro de div */ }
    presentes = await Promise.all(boxes.map(b => b.count()));
    if (presentes.every(n => n === 1)) {
      for (const box of boxes) if (!(await box.isChecked())) await box.check({ force: true, timeout: 15000 });
      if ((await Promise.all(boxes.map(b => b.isChecked()))).every(Boolean)) return 'TRES_VALORES_PORTAL_VERIFICADOS';
    }
    // Evidencia parcial: 3/3 en UI como captura aportada. Solo descargar a cuarentena.
    return 'SOLO_INDICADOR_UI_3_DE_3_NO_APTO_PUBLICACION';
  }
  stop('FRONTERAS_SIN_EVIDENCIA', 'No se identifican las tres fronteras ni el indicador seleccionado 3/3.');
}

async function prepararRango(frame, inicioMes, finMes, manifest) {
  progreso('FILTROS', `configurando Fecha inicial ${inicioMes}, Fecha final ${finMes} (UNA exportación)`);
  await esperarCondicion('FORMULARIO_READY', () => listoParaPeriodo(frame));
  manifest.fronterasConfirmacion = await confirmarFronteras(frame);
  const principal = frame.locator('#principal');
  if (await principal.count() !== 1) stop('MEDIDOR_PRINCIPAL_NO_LOCALIZADO', 'Falta medidor principal único.');
  if (!(await principal.isChecked())) await principal.check({ force: true, timeout: 15000 });
  const fechaI = frame.locator('#fechaI:visible');
  const fechaF = frame.locator('#fechaF:visible');
  if ((await fechaI.getAttribute('type')) !== 'month' || (await fechaF.getAttribute('type')) !== 'month')
    stop('FORMATO_FECHA_CAMBIO', 'Controles #fechaI y #fechaF ya no son tipo month; revisar portal.');
  await fechaI.fill(inicioMes, { timeout: 20000 });
  await fechaI.press('Tab'); // activar blur/change nativo antes de llenar fin
  await fechaF.fill(finMes, { timeout: 20000 });
  await fechaF.press('Tab');
  await esperarCondicion('RANGO_APLICADO', async () =>
    await listoParaPeriodo(frame) &&
    await fechaI.inputValue() === inicioMes && await fechaF.inputValue() === finMes &&
    await principal.isChecked(), UI_TIMEOUT_MS, 2500);
  const boton = frame.getByRole('button', { name: /Descargar consumos/i });
  if (await boton.count() !== 1) stop('BOTON_DESCARGAR_NO_UNICO', 'Descargar consumos no localizado inequívocamente.');
  await esperarCondicion('DESCARGAR_LISTO', async () =>
    await boton.isVisible() && await boton.isEnabled() &&
    !(await busyVisible(frame)) &&
    await fechaI.inputValue() === inicioMes && await fechaF.inputValue() === finMes,
    QUERY_TIMEOUT_MS, 2200);
  progreso('FILTROS_LISTOS', 'Se comprobó rango + medidor + botón habilitado. Sin clic en Buscar: reproduce el flujo manual de las imágenes.');
}

function escucharDescarga(context) {
  let resolver;
  const promise = new Promise(resolve => { resolver = resolve; });
  const listening = new Map();
  const attach = p => {
    if (listening.has(p)) return;
    const callback = d => resolver(d);
    p.on('download', callback);
    listening.set(p, callback);
  };
  context.pages().forEach(attach);
  context.on('page', attach);
  return {
    esperar: ms => Promise.race([promise, new Promise(resolve => setTimeout(() => resolve(null), ms))]),
    parar: () => { context.off('page', attach); for (const [p, fn] of listening) p.off('download', fn); }
  };
}

// Inspección local del archivo; puede llamarse GUID SIN EXTENSIÓN aunque sí sea Excel.
// No usamos nombres del servidor para decidir el formato ni mostramos el contenido.
function entradasZip(data) {
  let posEOCD = -1;
  for (let i = data.length - 22; i >= Math.max(0, data.length - 65557); i--) {
    if (data.readUInt32LE(i) === 0x06054b50) { posEOCD = i; break; }
  }
  if (posEOCD < 0) return { nombres: [], workbook: null };
  const total = data.readUInt16LE(posEOCD + 10);
  let p = data.readUInt32LE(posEOCD + 16);
  const nombres = [];
  let workbook = null;
  for (let i = 0; i < Math.min(total, 20000); i++) {
    if (p + 46 > data.length || data.readUInt32LE(p) !== 0x02014b50) break;
    const tipo = data.readUInt16LE(p + 10);
    const compLen = data.readUInt32LE(p + 20);
    const nlen = data.readUInt16LE(p + 28), extra = data.readUInt16LE(p + 30), comment = data.readUInt16LE(p + 32);
    const localOff = data.readUInt32LE(p + 42);
    const nombre = data.subarray(p + 46, p + 46 + nlen).toString('utf8');
    nombres.push(nombre);
    if (nombre === 'xl/workbook.xml' && compLen < 2000000 && localOff + 30 < data.length && data.readUInt32LE(localOff) === 0x04034b50) {
      const localName = data.readUInt16LE(localOff + 26), localExtra = data.readUInt16LE(localOff + 28);
      const pos = localOff + 30 + localName + localExtra;
      if (pos + compLen <= data.length) {
        const compressed = data.subarray(pos, pos + compLen);
        try { workbook = (tipo === 8 ? inflateRawSync(compressed) : tipo === 0 ? compressed : null)?.toString('utf8').slice(0, 250000); }
        catch { workbook = null; }
      }
    }
    p += 46 + nlen + extra + comment;
  }
  return { nombres, workbook };
}
function clasificarBytes(bytes) {
  if (bytes.length < 10) return { ext: '.bin', clase: 'DEMASIADO_PEQUENO', hojas: [] };
  if (bytes[0] === 0x50 && bytes[1] === 0x4b) {
    const zip = entradasZip(bytes);
    if (zip.nombres.includes('[Content_Types].xml') && zip.nombres.includes('xl/workbook.xml')) {
      const hojas = [];
      for (const m of zip.workbook?.matchAll(/<sheet\b[^>]*\bname="([^"]{1,110})"/gi) || []) {
        hojas.push(m[1].replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>'));
      }
      const requeridas = ['Activa', 'Reactiva Inductiva', 'Reactiva Capacitiva', 'Reactiva Inductiva Penalizada'];
      const hojasOK = requeridas.every(n => hojas.some(h => h.trim().toLowerCase() === n.toLowerCase()));
      return { ext: '.xlsx', clase: 'XLSX_REAL', hojas: hojas.slice(0, 30), cuatroHojas: hojasOK };
    }
    return { ext: '.zip', clase: 'ZIP_NO_XLSX', hojas: [] };
  }
  if (bytes.subarray(0, 8).equals(Buffer.from([0xd0,0xcf,0x11,0xe0,0xa1,0xb1,0x1a,0xe1])))
    return { ext: '.xls', clase: 'OLE_XLS_POR_INSPECCION_PENDIENTE', hojas: [] };
  if (bytes.subarray(0, 4).toString() === '%PDF') return { ext: '.pdf', clase: 'PDF_NO_ES_EXCEL', hojas: [] };
  const ini = bytes.subarray(0, 200).toString('utf8').trim().toLowerCase();
  if (/^(<!doctype html|<html|<\?xml)/.test(ini) || ini.startsWith('{'))
    return { ext: '.bin', clase: 'RESPUESTA_NO_EXCEL_HTML_JSON_XML', hojas: [] };
  return { ext: '.bin', clase: 'DESCONOCIDO', hojas: [] };
}

async function buscarDescargaEnDisco(dir, maxMs) {
  // Rescate limitado si Playwright no emitió el evento pero Chromium dejó UUID en el disco.
  const limite = Date.now() + maxMs;
  const visto = new Map();
  while (Date.now() < limite) {
    for (const nombre of await fs.readdir(dir).catch(() => [])) {
      if (/\.(crdownload|part|tmp)$/i.test(nombre)) continue;
      const full = path.join(dir, nombre);
      const stat = await fs.stat(full).catch(() => null);
      if (!stat?.isFile() || stat.size < 100) continue;
      const actual = visto.get(nombre);
      if (actual && actual.size === stat.size && Date.now() - actual.since > 3000) return full;
      if (!actual || actual.size !== stat.size) visto.set(nombre, { size: stat.size, since: Date.now() });
    }
    await new Promise(resolve => setTimeout(resolve, 750));
  }
  return null;
}
async function descargarRango(frame, context, ini, fin) {
  const boton = frame.getByRole('button', { name: /Descargar consumos/i });
  const listener = escucharDescarga(context);  // ANTES del click
  const raw = path.join(DOWNLOADS, `ENEL_${ini}_a_${fin}_${STAMP}.recibido`);
  let procedencia = 'EVENTO_PLAYWRIGHT';
  try {
    progreso('DESCARGA', `clic Descargar consumos (${ini} → ${fin}) y esperar archivo, no asumir éxito por historial Chrome`);
    await boton.click({ timeout: 30000 });
    const download = await listener.esperar(DOWNLOAD_TIMEOUT_MS);
    if (download) {
      // saveAs espera a que finalice y persiste fuera del directorio temporal de Chromium.
      await download.saveAs(raw);
      const failed = await download.failure();
      if (failed) stop('DESCARGA_FALLIDA', 'Chromium notificó que la descarga terminó con error.');
    } else {
      progreso('DESCARGA', 'sin evento download; examinando exclusivamente la carpeta temporal privada de esta ejecución');
      const rescate = await buscarDescargaEnDisco(BROWSER_DOWNLOADS, 15000);
      if (!rescate) stop('SIN_ARCHIVO_DESCARGADO', 'El navegador no emitió evento download ni quedó un archivo completo en la carpeta temporal; NO se obtuvo Excel.');
      await fs.copyFile(rescate, raw);
      procedencia = 'RESCATE_DE_DISCO_TEMPORAL';
    }
    const size = (await fs.stat(raw)).size;
    if (size > 100 * 1024 * 1024) stop('ARCHIVO_EXCEDE_LIMITE', 'Archivo preservado, tamaño excede el límite de inspección de 100 MiB.');
    const bytes = await fs.readFile(raw);
    const tipo = clasificarBytes(bytes);
    const destino = path.join(DOWNLOADS, `ENEL_${ini}_a_${fin}_${STAMP}${tipo.ext}`);
    await fs.rename(raw, destino);
    const result = {
      inicio: ini, fin, ubicacion: destino, nombre: path.basename(destino), bytes: bytes.length,
      sha256: createHash('sha256').update(bytes).digest('hex'),
      origen: procedencia, formato: tipo.clase,
      hojas: tipo.hojas, cuatroHojasEsperadas: Boolean(tipo.cuatroHojas),
      publicacion: 'BLOQUEADA_R045_R046_IDENTIFICADORES_SIN_CONCILIAR'
    };
    console.log(`ARCHIVO CONSERVADO EN: ${destino}`);
    console.log(`Formato: ${tipo.clase}. Hojas esperadas: ${tipo.cuatroHojas ? 'SI' : 'NO CONFIRMADAS'}. SHA256: ${result.sha256}`);
    return result;
  } finally { listener.parar(); }
}

async function retenerEnFallo(browser, manifest, page) {
  if (!INTERACTIVE || !browser || !page || estadoRuta(page) === 'LOGIN') return;
  console.log('Diagnóstico retenido: Chromium permanece abierto hasta Enter o 8 minutos (lo que ocurra primero).');
  console.log('Inspeccione pestaña/controles localmente. NO copie cookies, tokens, valores de login ni Network headers.');
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  try {
    await Promise.race([rl.question('Presione Enter para cerrar Chromium: '), new Promise(resolve => setTimeout(resolve, HOLD_MS))]);
  } catch { /* consola cerrada */ }
  finally { rl.close(); manifest.inspeccionLocal = 'PAUSA_CONTROLADA'; }
}

await fs.mkdir(OUT, { recursive: true });
await fs.mkdir(DOWNLOADS, { recursive: true });
await fs.mkdir(BROWSER_DOWNLOADS, { recursive: true });
const manifest = {
  version: 'R047-ENEL-MES-ANTERIOR-ACTUAL-DESCARGA-PERSISTENTE-20261025', stamp: STAMP, modo: DIAGNOSTIC ? 'DIAGNOSTICO' : 'DESCARGA_CONTROLADA',
  periodos: periodsBogota(), rangoUnico: 'MES_ANTERIOR_A_MES_ACTUAL', carpetaDescargas: DOWNLOADS, medidor: 'principal', fronterasPortalSinConciliar: FRONTIERS,
  estado: 'INICIADO', auth: 'SIN_INICIAR', results: [],
  advertencia: 'ID comercial/frontera R045 vs Work R046 en contradicción: PROHIBIDA publicación ARMA/Sheets.'
};
const diag = { ruta: 'NO_INICIADO', pantalla: 'NO_OBSERVADA', controles: null };
const network = []; // únicamente metadatos no identificantes; sin URL, cuerpo, headers ni claves.
let browser = null;
let page = null;
try {
  browser = await chromium.launch({ headless: UNATTENDED, downloadsPath: BROWSER_DOWNLOADS });
  const context = await browser.newContext({ acceptDownloads: true });
  context.on('page', p => {
    p.setDefaultTimeout(15000);
    p.on('response', r => {
      try {
        const u = new URL(r.url());
        if (u.origin !== ORIGIN || network.length >= 250) return;
        const type = r.headers()['content-type'] || '';
        const ct = /spreadsheet|excel|zip|octet-stream/i.test(type) ? 'POSIBLE_ARCHIVO' :
          /json/i.test(type) ? 'JSON' : /html/i.test(type) ? 'HTML' : 'OTRO';
        network.push({ etapa: manifest.estado, status: r.status(), recurso: r.request().resourceType(), categoria: ct });
      } catch { /* omitir */ }
    });
  });
  page = await context.newPage();
  page.setDefaultTimeout(15000);
  manifest.estado = 'AUTENTICANDO';
  await autenticar(page, manifest);
  manifest.estado = 'NAVEGANDO_CONSUMOS';
  const frame = await seleccionarConsumos(page, diag);
  diag.controles = await diagnosticarInterfaz(page);
  manifest.estado = 'PANTALLA_CONSUMOS_CONFIRMADA';
  console.log('OK: Consumos medidos confirmada y controles estables (sin exportación en modo diagnóstico).');
  if (!EXPORT) {
    manifest.estado = 'DIAGNOSTICO_OK_NO_DESCARGA';
    console.log('Diagnóstico finalizado. No se descargó ni publicó información.');
  } else {
    const [mesAnterior, mesActual] = manifest.periodos;
    manifest.estado = 'PREPARANDO_RANGO_UNICO';
    await prepararRango(frame, mesAnterior, mesActual, manifest);
    manifest.estado = 'DESCARGANDO_RANGO_UNICO';
    const result = await descargarRango(frame, context, mesAnterior, mesActual);
    manifest.results.push(result);
    if (!['XLSX_REAL', 'OLE_XLS_POR_INSPECCION_PENDIENTE'].includes(result.formato))
      stop('ARCHIVO_RECIBIDO_PERO_NO_EXCEL', `Archivo conservado pero no es Excel: ${result.formato}. Revisar localmente; no procesar.`);
    manifest.estado = result.cuatroHojasEsperadas ? 'XLSX_4_HOJAS_RECIBIDO_PENDIENTE_VALIDACION' : 'ARCHIVO_RECIBIDO_PENDIENTE_VERIFICAR_HOJAS';
    console.log('No se publican datos: primero validar identificadores comerciales y contenido con R045.');
  }
} catch (e) {
  const err = codigoDeError(e);
  manifest.estado = err.codigo;
  manifest.errorSeguro = err.detalle;
  console.error(`R047 detenido [${err.codigo}]: ${err.detalle}`);
  if (page && sitioAutorizado(page) && estadoRuta(page) !== 'LOGIN' && !(await hayFormularioLogin(page))) {
    diag.controles = await diagnosticarInterfaz(page).catch(() => ({ noDisponible: true }));
    if (CAPTURE && ['SESION_EXISTENTE', 'AUTOMATICA_CONFIRMADA', 'RENOVADA_CONFIRMADA', 'INTERVENCION_HUMANA_CONFIRMADA'].includes(manifest.auth) && estadoRuta(page) === 'ESTADISTICAS_CONSUMO') {
      // Captura privada OPCIONAL sólo en ruta post-login confirmada. Puede contener datos comerciales; NO compartir sin revisar.
      await page.screenshot({ path: path.join(OUT, 'captura_privada.png'), fullPage: false }).catch(() => {});
    }
  }
  process.exitCode = 1;
} finally {
  diag.rutaFinal = page ? estadoRuta(page) : 'SIN_NAVEGADOR';
  await fs.writeFile(path.join(OUT, 'manifest.json'), JSON.stringify(manifest, null, 2), { mode: 0o600 }).catch(() => {});
  await fs.writeFile(path.join(OUT, 'diagnostico_seguro.json'), JSON.stringify(diag, null, 2), { mode: 0o600 }).catch(() => {});
  await fs.writeFile(path.join(OUT, 'respuestas_sin_secretos.json'), JSON.stringify(network, null, 2), { mode: 0o600 }).catch(() => {});
  console.log(`Evidencia privada en: ${OUT}`);
  console.log(`Carpeta de archivos descargados: ${DOWNLOADS}`);
  if (process.exitCode && browser) await retenerEnFallo(browser, manifest, page);
  if (browser) await browser.close().catch(() => {});
}
