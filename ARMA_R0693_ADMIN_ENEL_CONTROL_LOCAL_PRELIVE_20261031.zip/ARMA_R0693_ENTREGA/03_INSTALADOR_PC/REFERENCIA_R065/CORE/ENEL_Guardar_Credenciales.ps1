﻿# A.R.D.A.N. / ENEL R046 — guardar/rotar credencial local mediante Windows DPAPI CurrentUser.
# Ejecutar solo en PowerShell 5.1 interactivo del MISMO usuario Windows del robot.
# No incluye credenciales; no muestra ni escribe password en claro.
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'Solo Windows.' }
Add-Type -AssemblyName System.Security
$base = Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R046'
$dir = Join-Path $base 'secrets'
$file = Join-Path $dir 'enel_credencial.dpapi'

# ACL explícita, sin herencia: cuenta Windows actual y SYSTEM.
function Set-PrivateDirectoryAcl([string] $directory) {
    $sid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User
    $sys = [System.Security.Principal.SecurityIdentifier]::new('S-1-5-18')
    $acl = New-Object System.Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)
    $inherit = [System.Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
    $prop = [System.Security.AccessControl.PropagationFlags]::None
    $type = [System.Security.AccessControl.AccessControlType]::Allow
    $acl.AddAccessRule([System.Security.AccessControl.FileSystemAccessRule]::new($sid, [System.Security.AccessControl.FileSystemRights]::FullControl, $inherit, $prop, $type))
    $acl.AddAccessRule([System.Security.AccessControl.FileSystemAccessRule]::new($sys, [System.Security.AccessControl.FileSystemRights]::FullControl, $inherit, $prop, $type))
    [System.IO.Directory]::SetAccessControl($directory, $acl)
}

[System.IO.Directory]::CreateDirectory($base) | Out-Null
[System.IO.Directory]::CreateDirectory($dir) | Out-Null
Set-PrivateDirectoryAcl $dir
Write-Host 'ENEL R046: actualización local de credenciales (DPAPI CurrentUser).'
Write-Host 'Escriba solo la credencial REAL y vigente del portal ENEL. No se deriva de la fecha.'
$user = Read-Host 'Usuario o correo ENEL'
if ([string]::IsNullOrWhiteSpace($user)) { throw 'Usuario vacío. No se guardó.' }
$secure = Read-Host 'Contraseña ENEL (entrada oculta)' -AsSecureString
if ($null -eq $secure -or $secure.Length -eq 0) { throw 'Contraseña vacía. No se guardó.' }
$ptr = [IntPtr]::Zero
$plain = $null
$json = $null
$bytes = $null
$cipher = $null
$tmp = $null
try {
    $ptr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    $plain = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    $json = ConvertTo-Json -InputObject @{ usuario = $user; password = $plain } -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $cipher = [System.Security.Cryptography.ProtectedData]::Protect(
        $bytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
    $tmp = Join-Path $dir ('cred_' + [Guid]::NewGuid().ToString('N') + '.tmp')
    [System.IO.File]::WriteAllBytes($tmp, $cipher)
    # Archivo final hereda ACL exclusiva del directorio; reemplazo atómico en mismo volumen.
    if ([System.IO.File]::Exists($file)) {
        [System.IO.File]::Replace($tmp, $file, $null)
    } else {
        [System.IO.File]::Move($tmp, $file)
    }
    # Asegurar ACL del archivo también si ya existía y fue reemplazado.
    $fileAcl = New-Object System.Security.AccessControl.FileSecurity
    $fileAcl.SetAccessRuleProtection($true, $false)
    $fileAcl.AddAccessRule([System.Security.AccessControl.FileSystemAccessRule]::new(
        [System.Security.Principal.WindowsIdentity]::GetCurrent().User,
        [System.Security.AccessControl.FileSystemRights]::FullControl,
        [System.Security.AccessControl.AccessControlType]::Allow))
    $fileAcl.AddAccessRule([System.Security.AccessControl.FileSystemAccessRule]::new(
        [System.Security.Principal.SecurityIdentifier]::new('S-1-5-18'),
        [System.Security.AccessControl.FileSystemRights]::FullControl,
        [System.Security.AccessControl.AccessControlType]::Allow))
    [System.IO.File]::SetAccessControl($file, $fileAcl)
    Write-Host 'Credencial DPAPI almacenada en el perfil local actual.'
    Write-Host 'No compartir el archivo cifrado: está ligado a esta identidad Windows.'
} finally {
    if ($ptr -ne [IntPtr]::Zero) { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
    if ($bytes) { [Array]::Clear($bytes, 0, $bytes.Length) }
    if ($cipher) { [Array]::Clear($cipher, 0, $cipher.Length) }
    if ($tmp -and [System.IO.File]::Exists($tmp)) { [System.IO.File]::Delete($tmp) }
    $plain = $null
    $json = $null
    $secure = $null
}
