﻿# A.R.D.A.N. / ENEL R046 — lector privado Windows DPAPI CurrentUser.
# USO EXCLUSIVO: subprocess de Node mediante stdout PIPE en memoria.
# NUNCA ejecutar manualmente ni redirigir stdout a archivo: genera secreto descifrado.
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { exit 4 }
if ($env:ARMA_DPAPI_PIPE -ne '1' -or -not [Console]::IsOutputRedirected) { exit 7 }
Add-Type -AssemblyName System.Security
$file = Join-Path (Join-Path (Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R046') 'secrets') 'enel_credencial.dpapi'
if (-not [System.IO.File]::Exists($file)) { exit 3 }
$bytes = $null
$plain = $null
try {
    $bytes = [System.IO.File]::ReadAllBytes($file)
    $plain = [System.Security.Cryptography.ProtectedData]::Unprotect(
        $bytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
    $utf = New-Object System.Text.UTF8Encoding($false)
    # El JSON ya está dentro de DPAPI. Se entrega SOLO al proceso Node que lo lee por pipe.
    $json = $utf.GetString($plain)
    $value = ConvertFrom-Json -InputObject $json
    if ([string]::IsNullOrWhiteSpace($value.usuario) -or [string]::IsNullOrWhiteSpace($value.password)) { exit 5 }
    [Console]::OutputEncoding = $utf
    [Console]::Out.Write($json)
    $json = $null
} catch {
    # No imprimir errores ni secreto en stderr.
    exit 6
} finally {
    if ($bytes) { [Array]::Clear($bytes, 0, $bytes.Length) }
    if ($plain) { [Array]::Clear($plain, 0, $plain.Length) }
}
