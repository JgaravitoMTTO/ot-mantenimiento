﻿# Ciclo R064/R050. Usa el downloader R047 YA PROBADO, mismo usuario DPAPI, NO modifica LIVE.
# Salida: manifiesto local y Sheets ENEL privado mediante receptor firmado independiente.
param([switch]$Prueba)
$ErrorActionPreference='Stop'
$root='C:\ARMA_ENEL_R046'
$node=Join-Path $root 'enel-r046.mjs'
$py=Join-Path $root 'ENEL_R061_Procesar_Enviar.py'
$cfg=Join-Path $root 'ENEL_R050_Config.json'
$reader=Join-Path $root 'ENEL_R050_Leer_Clave_DPAPI.ps1'
$motor045=Join-Path $root 'R045_PROCESAR_COPIA_R050.py'
$config045=Join-Path $root 'R045_Config_CONCILIADO_R050.json'
$local=Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R046'
$dir=Join-Path $local 'orquestador_r061'
[IO.Directory]::CreateDirectory($dir)|Out-Null
$state=Join-Path $dir 'estado.json'
$lockfile=Join-Path $dir 'ciclo.lock'
$lock=$null
function Status([string]$s,[string]$detail){
  $o=[ordered]@{stamp=([DateTime]::UtcNow.ToString('o'));status=$s;detail=$detail}
  $o|ConvertTo-Json -Compress|Set-Content -LiteralPath $state -Encoding UTF8
  Write-Host "R050: $s -- $detail"
}
try{
  $lock=[IO.File]::Open($lockfile,'OpenOrCreate','ReadWrite','None')
  if(!(Test-Path $node) -or !(Test-Path $py) -or !(Test-Path $cfg) -or !(Test-Path $reader) -or !(Test-Path $motor045) -or !(Test-Path $config045)){
    throw 'COMPONENTES_R050_FALTANTES'
  }
  . (Join-Path $root 'ENEL_R064_Resolver_Entorno.ps1')
  $runtime=ARMA_R064_GetRuntime
  if($null -eq $runtime){throw 'NODE_O_PYTHON_NO_RESUELTO_EN_USUARIO_ACTUAL'}
  $pythonParams=@($runtime.PythonArgs)
  Push-Location $root
  try{
    Status 'DESCARGANDO' 'Esperando EXCEL real y validacion de cuatro hojas'
    $start=[DateTime]::UtcNow
    if($Prueba){& $runtime.Node .\enel-r046.mjs --diagnostico --desatendido 2>&1|Out-Host}
    else{& $runtime.Node .\enel-r046.mjs --descargar --desatendido 2>&1|Out-Host}
    $code=$LASTEXITCODE
    if($code -ne 0){throw ('PENDIENTE_DESCARGA_O_AUTENTICACION_'+$code)}
    if($Prueba){Status 'DIAGNOSTICO_OK' 'Sin descargar ni escribir Sheets';return}
    $manifests=Get-ChildItem -LiteralPath (Join-Path $local 'ejecuciones') -Filter 'manifest.json' -File -Recurse |
       Where-Object {$_.LastWriteTimeUtc -ge $start.AddSeconds(-5)}|Sort-Object LastWriteTimeUtc -Descending
    if(!$manifests -or $manifests.Count -lt 1){throw 'MANIFEST_DESCARGA_NO_ENCONTRADO'}
    $mf=$manifests[0].FullName
    $j=Get-Content -LiteralPath $mf -Raw | ConvertFrom-Json
    if($j.estado -ne 'XLSX_4_HOJAS_RECIBIDO_PENDIENTE_VALIDACION' -or @($j.results).Count -ne 1){throw 'MANIFEST_NO_APROBADO'}
    # Ejecutar R045 HISTORICO sin alterar sus originales. Configuracion corregida
    # por cuenta/frontera; sin atribuir SUB1/SUB2 fisico.
    Status 'ANALITICA_R045' 'Procesando XLSX a SQLite/CSV privados con el motor R045'
    $fileENEL=[string]$j.results[0].ubicacion
    $out045=Join-Path $local 'r045_analitica_conciliada_r050'
    [IO.Directory]::CreateDirectory($out045)|Out-Null
    $descarga=(Get-Date -Format 'yyyy-MM-ddTHH:mm:sszzz')
    $logR045=Join-Path $dir 'auditoria_r045.log'
    & $runtime.Python @pythonParams $motor045 $fileENEL --config $config045 --out $out045 --descarga $descarga *> $logR045
    if($LASTEXITCODE -ne 0){throw ('PENDIENTE_ANALITICA_R045_'+$LASTEXITCODE+'_REVISAR_LOG_LOCAL')}
    Status 'INGIRIENDO' 'Cotejando cuatro magnitudes, 3 cuentas, SHA256 y actualizaciones'
    & $runtime.Python @pythonParams $py --manifest $mf --config $cfg --dpapi $reader 2>&1|Out-Host
    if($LASTEXITCODE -ne 0){throw ('PENDIENTE_INGESTA_'+$LASTEXITCODE)}
    Status 'OK' 'Receptor confirmo carga y cierre seguro; validar resumen en Lecturas'
  }finally{Pop-Location}
}catch [System.IO.IOException]{
  Status 'PENDIENTE_CONCURRENCIA' 'Existe otra ejecucion del ciclo R050.'
  exit 5
}catch{
  $reason=[string]$_.Exception.Message
  if($reason -match 'PENDIENTE_DESCARGA') {Status 'PENDIENTE_INTERVENCION' 'Autenticacion, MFA o descarga sin confirmar; consultar estado R047.'}
  else {Status 'PENDIENTE_REVISION' $reason}
  exit 1
}finally{
 if($null -ne $lock){$lock.Dispose()}
}
