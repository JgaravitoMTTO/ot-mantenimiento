# ARMA R064 - handler del esquema ya instalado arma-enel-r052://actualizar.
# NO recibe URI como argumento, NO instala servicio, NO abre puertos.
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
$root='C:\ARMA_ENEL_R046'
$check=Join-Path $root 'ENEL_R061_Verificar_Ciclo.ps1'
$cycle=Join-Path $root 'ENEL_R061_Ciclo_Automatico.ps1'
if(!(Test-Path -LiteralPath $check) -or !(Test-Path -LiteralPath $cycle)){
  [System.Windows.Forms.MessageBox]::Show('AGENTE R064 INCOMPLETO. No se descargaron datos.','A.R.M.A. | ENEL')|Out-Null
  exit 3
}
& powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $check
$code=$LASTEXITCODE
if($code -ne 0){
  [System.Windows.Forms.MessageBox]::Show(
   "PRECONDICION R064 NO SUPERADA (codigo $code). No se descargaron ni enviaron datos. Abra PowerShell con su usuario habitual y ejecute: cd C:\ARMA_ENEL_R046; .\ENEL_R061_Verificar_Ciclo.ps1. El diagnostico indicara si falta Node, Python, Playwright, HMAC u otro componente.",
   'A.R.M.A. | ENEL - SIN DESCARGA')|Out-Null
  exit $code
}
$reply=[System.Windows.Forms.MessageBox]::Show(
 'La verificacion local termino correctamente. Se ejecutara la descarga ENEL R047 y la ingesta firmada. Solo se cerraran dias anteriores a hoy. ¿Continuar?',
 'A.R.M.A. | ACTUALIZAR ENEL',
 [System.Windows.Forms.MessageBoxButtons]::YesNo,
 [System.Windows.Forms.MessageBoxIcon]::Question)
if($reply -ne [System.Windows.Forms.DialogResult]::Yes){exit 0}
Push-Location $root
try{
 & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $cycle
 $code=$LASTEXITCODE
 if($code -ne 0){
  $state=Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R046\orquestador_r061\estado.json'
  [System.Windows.Forms.MessageBox]::Show(
    "El ciclo ENEL NO termino correctamente (codigo $code). Consulte $state. NO cambie contrasenas sin diagnostico.",
    'A.R.M.A. | ENEL - PENDIENTE')|Out-Null
  exit $code
 }
 [System.Windows.Forms.MessageBox]::Show(
   'El receptor confirmo la ingesta. Verifique el corte en ENEL_CONTROL y el resumen de las nueve variables en ARMA.','A.R.M.A. | ENEL - OK')|Out-Null
}finally{Pop-Location}
