# Solo invocar desde ENEL_R050_Procesar_Enviar.py; stdout incluye secreto en memoria.
# NUNCA ejecute para copiar su salida a un log.
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Security
$f=Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R046\secrets\enel_ingesta_r050.dpapi'
if(!(Test-Path -LiteralPath $f)){exit 6}
$b=[IO.File]::ReadAllBytes($f)
$raw=[System.Security.Cryptography.ProtectedData]::Unprotect($b,$null,[System.Security.Cryptography.DataProtectionScope]::CurrentUser)
try{[Console]::Out.Write([Text.Encoding]::UTF8.GetString($raw))}finally{[Array]::Clear($raw,0,$raw.Length)}
