#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ARMA ENEL R045 -- ETL reproducible sin librerias externas, sin credenciales.
Lee OOXML xlsx con Python estandar; datos siempre privados. Compatible Windows.
Uso: python procesar_enel.py "Consumos medidos ...xlsx" [--config config.json] [--out DIR]
Reimportacion: se compara cada valor horario por cuenta/fecha/hoja y se conserva
la fuente mas reciente, registrando cada cambio en SQLite/auditoria.
"""
from __future__ import annotations
import argparse, calendar, csv, datetime as dt, hashlib, io, json, math, re, sqlite3, sys, zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from collections import defaultdict

NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
    'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
SHEET_KINDS={
    'Activa':'P_KWH',
    'Reactiva Inductiva':'QI_KVARH',
    'Reactiva Capacitiva':'QC_KVARH',
    'Reactiva Inductiva Penalizada':'QPI_KVARH'
}
FIELDS=['FECHA','CUENTA','SUBESTACION','PLANTA','FRONTERA','ACTIVA_KWH','QI_KVARH','QC_KVARH','Q_INDUCTIVA_PENALIZADA_KVARH',
        'FP_INDUCTIVO_DIARIO','FP_CAPACITIVO_DIARIO_INDICADOR','HORAS_INDUCTIVAS_EXCESO','HORAS_FP_BAJO_090',
        'HORAS_CAPACITIVAS','RATIO_QI_P','ALERTA','CALIDAD','VERSION','DESCARGA_LOCAL','ULTIMA_HORA_INFERIDA']
VAR_TYPES=[('ACTIVA','ACTIVA_KWH','kWh'),('FP','FP_INDUCTIVO_DIARIO','adimensional'),('R_PENALIZADA','Q_INDUCTIVA_PENALIZADA_KVARH','kVArh')]

def colnum(a):
    x=0
    for ch in re.match('[A-Z]+',a).group(): x=x*26+ord(ch)-64
    return x-1

def read_ooxml(path):
    """Lee OOXML sin librerias de terceros; requiere .xlsx real, no cifrado."""
    with zipfile.ZipFile(path) as z:
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            root=ET.fromstring(z.read('xl/sharedStrings.xml'))
            for si in root.findall('m:si',NS):
                strings.append(''.join((t.text or '') for t in si.findall('.//m:t',NS)))
        wb=ET.fromstring(z.read('xl/workbook.xml'))
        rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        relation={x.attrib['Id']:x.attrib['Target'] for x in rels}
        result={}
        for sh in wb.findall('m:sheets/m:sheet',NS):
            name=sh.attrib['name']
            if name not in SHEET_KINDS: continue
            rid=sh.attrib.get('{%s}id'%NS['r'])
            target=relation[rid].lstrip('/')
            target=target if target.startswith('xl/') else 'xl/'+target
            if target not in z.namelist():raise ValueError('Hoja sin XML '+name)
            data=[]
            with z.open(target) as fh:
                for event,e in ET.iterparse(fh,events=('end',)):
                    if e.tag!='{%s}row'%NS['m']:continue
                    rowidx=int(e.attrib.get('r','0'))
                    if rowidx>=3:
                        row=[None]*27
                        for c in e.findall('m:c',NS):
                            idx=colnum(c.attrib['r'])
                            if not 0<=idx<27:continue
                            typ=c.attrib.get('t','')
                            v=c.find('m:v',NS)
                            if typ=='inlineStr':
                                ts=c.findall('.//m:t',NS)
                                row[idx]=''.join(t.text or '' for t in ts)
                            elif v is not None and v.text is not None:
                                raw=v.text
                                if typ=='s':row[idx]=strings[int(raw)]
                                elif typ in ('str','e'):row[idx]=raw
                                else:
                                    try: row[idx]=float(raw)
                                    except ValueError:row[idx]=raw
                        if row[0] is not None and row[1] is not None:data.append(row)
                    e.clear()
            result[name]=data
        absent=set(SHEET_KINDS)-set(result)
        if absent:raise ValueError('Faltan hojas ENEL: '+str(absent))
        return result

def dmy(raw):
    if isinstance(raw,(float,int)):
        return (dt.datetime(1899,12,30)+dt.timedelta(days=float(raw))).date().isoformat()
    txt=str(raw).strip().split()[0]
    if re.match(r'^\d{2}/\d{2}/\d{4}$',txt): return dt.datetime.strptime(txt,'%d/%m/%Y').date().isoformat()
    if re.match(r'^\d{4}-\d{2}-\d{2}$',txt):return txt
    raise ValueError('Fecha inesperada: '+str(raw))

def number(n):
    if n is None or n=='':return None
    if isinstance(n,(float,int)) and math.isfinite(n):return round(float(n),5)
    if isinstance(n,str):
        v=n.replace(' ','').replace(',','.')
        try:return round(float(v),5)
        except ValueError:return None
    return None

def hashfile(path):
    sha=hashlib.sha256()
    with open(path,'rb') as fh:
        while x:=fh.read(1024*1024):sha.update(x)
    return sha.hexdigest()

def write_csv(path,rows,fields):
    with open(path,'w',encoding='utf-8-sig',newline='') as fh:
        w=csv.DictWriter(fh,fieldnames=fields,extrasaction='ignore',delimiter=';')
        w.writeheader();w.writerows(rows)

def maybe_float(x,d=3):return round(x,d) if x is not None and math.isfinite(x) else ''

def load_invoices(p):
    out={}
    if not p.exists():return out
    with p.open('r',encoding='utf-8-sig',newline='') as fh:
        for a in csv.DictReader(fh,delimiter=';'):
            if a.get('CUENTA') and a.get('PERIODO'):
                out[(a['CUENTA'],a['PERIODO'])]=a
    return out

def main():
    a=argparse.ArgumentParser()
    a.add_argument('archivo',type=Path,help='XLSX original exportado por ENEL')
    a.add_argument('--config',type=Path,default=Path(__file__).with_name('config.example.json'))
    a.add_argument('--out',type=Path,default=Path(__file__).with_name('datos_privados'))
    a.add_argument('--descarga',type=str,default='',help='ISO-8601 hora local conocida. Sin supuesto si se omite.')
    args=a.parse_args()
    config=json.loads(args.config.read_text(encoding='utf-8'))
    accmap=config['cuentas']
    output=args.out.resolve();output.mkdir(parents=True,exist_ok=True)
    target=args.archivo.resolve()
    source_sha=hashfile(target)
    timestamp=args.descarga or ''
    if not timestamp:
        timestamp=dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec='seconds')
        download_known=False
    else:download_known=True
    data=read_ooxml(target)
    db=sqlite3.connect(str(output/'ENEL_HISTORICO.sqlite'))
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('CREATE TABLE IF NOT EXISTS horas (cuenta TEXT, fecha TEXT, tipo TEXT, hora INTEGER, valor REAL, sha TEXT, descarga TEXT, PRIMARY KEY(cuenta,fecha,tipo,hora))')
    db.execute('CREATE TABLE IF NOT EXISTS revisiones (id INTEGER PRIMARY KEY AUTOINCREMENT, cuenta TEXT, fecha TEXT, tipo TEXT, hora INTEGER, anterior REAL, nuevo REAL, sha TEXT, descarga TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS importaciones (sha TEXT PRIMARY KEY, archivo TEXT, descarga TEXT, filas INTEGER, cambio_valores INTEGER, momento_procesamiento TEXT)')
    rows_seen=0;changes=0;older_skipped=0;unknown=set();dup=0;total_diff=0
    with db:
        for sn,rows in data.items():
            typ=SHEET_KINDS[sn]
            for row in rows:
                key=str(int(row[0])) if isinstance(row[0],(int,float)) else str(row[0]).strip()
                if key not in accmap:unknown.add(key);continue
                date=dmy(row[1]);hours=list(map(number,row[2:26]))
                if len(hours)!=24:raise RuntimeError('No hay 24 columnas horarias')
                if any(v is None for v in hours):
                    # Se conserva vacio como ausencia, no cero supuesto
                    pass
                eneltotal=number(row[26]);computed=sum(v for v in hours if v is not None)
                if eneltotal is not None and abs(eneltotal-computed)>max(0.06,computed*1e-5):total_diff+=1
                rows_seen+=1
                for hour,value in enumerate(hours):
                    if value is None:continue
                    old=db.execute('SELECT valor,descarga FROM horas WHERE cuenta=? AND fecha=? AND tipo=? AND hora=?',(key,date,typ,hour)).fetchone()
                    if old is not None and abs(old[0]-value)<0.001:dup+=1;continue
                    if old is not None and timestamp<=str(old[1] or ''):
                        older_skipped+=1;continue
                    if old is not None:
                        db.execute('INSERT INTO revisiones(cuenta,fecha,tipo,hora,anterior,nuevo,sha,descarga) VALUES(?,?,?,?,?,?,?,?)',(key,date,typ,hour,old[0],value,source_sha,timestamp))
                    db.execute('INSERT INTO horas VALUES (?,?,?,?,?,?,?) ON CONFLICT(cuenta,fecha,tipo,hora) DO UPDATE SET valor=excluded.valor,sha=excluded.sha,descarga=excluded.descarga',(key,date,typ,hour,value,source_sha,timestamp))
                    changes+=1
        db.execute('INSERT OR REPLACE INTO importaciones VALUES (?,?,?,?,?,?)',(source_sha,target.name,timestamp,rows_seen,changes,dt.datetime.now(dt.timezone.utc).isoformat()))
    allvalues=defaultdict(dict)
    for acct,date,typ,hour,v,sha,down in db.execute('SELECT cuenta,fecha,tipo,hora,valor,sha,descarga FROM horas ORDER BY fecha,cuenta,hora'):
        allvalues[(acct,date)].setdefault(typ,{})[hour]=v
    download_date=dt.date.fromisoformat(timestamp[:10]) if timestamp else dt.datetime.now().date()
    # Siempre D-1 como maximo; evita publicar dia con ceros de espera.
    cutoff=(download_date-dt.timedelta(days=1)).isoformat()
    control=[];horas=[];long=[];incomplete=[];quality_counts=defaultdict(int)
    for (acct,date),kinds in sorted(allvalues.items(),key=lambda x:(x[0][1],x[0][0])):
        if date>cutoff:continue
        p=kinds.get('P_KWH',{});qi=kinds.get('QI_KVARH',{});qc=kinds.get('QC_KVARH',{});qpi=kinds.get('QPI_KVARH',{})
        problems=[]
        if len(p)!=24:problems.append('ACTIVA_SIN_24_HORAS')
        if len(qi)!=24:problems.append('INDUCTIVA_SIN_24_HORAS')
        if len(qc)!=24:problems.append('CAPACITIVA_SIN_24_HORAS')
        if len(qpi)!=24:problems.append('PENALIZADA_SIN_24_HORAS')
        if any(x<0 for d in (p,qi,qc,qpi) for x in d.values()):problems.append('VALOR_NEGATIVO')
        # Cero final en Activa NO siempre indica retardo; se marca para revision.
        if p and any(x>0 for x in p.values()) and all(p.get(h,0)==0 for h in range(20,24)):
            problems.append('POTENCIAL_COLA_EN_CEROS')
        if len(p)==24 and sum(p.values())==0:problems.append('ACTIVA_CERO_24H_REVISAR')
        qtuple=[p,qi,qc,qpi]
        complete=all(len(x)==24 for x in qtuple)
        if not complete:quality_counts['incompleto']+=1
        for h in range(24):
            if any(h not in q for q in qtuple):continue
            ph,ih,ch,pen=[q[h] for q in qtuple]
            hour_pf=ph/math.sqrt(ph*ph+ih*ih) if ph>0 or ih>0 else None
            hour_over= max(0.0,ih-0.5*ph) if ph>=0 else None
            horas.append({'FECHA':date,'CUENTA':acct,'SUBESTACION':accmap[acct]['etiqueta'],'HORA':h,
                          'ACTIVA_KWH':ph,'QI_KVARH':ih,'QC_KVARH':ch,'Q_INDUCTIVA_PENALIZADA_REPORTADA_KVARH':pen,
                          'FP_INDUCTIVO_HORARIO_INDICADOR':maybe_float(hour_pf,6),'SOBRE_50_QI_P':1 if ih>0.5*ph else 0,
                          'EXCESO_ESTIMADO_QI_KVARH':maybe_float(hour_over,3)})
        sum_p=sum(p.values()) if len(p)==24 else None
        sum_qi=sum(qi.values()) if len(qi)==24 else None
        sum_qc=sum(qc.values()) if len(qc)==24 else None
        sum_qpi=sum(qpi.values()) if len(qpi)==24 else None
        fp=sum_p/math.sqrt(sum_p**2+sum_qi**2) if sum_p is not None and sum_qi is not None and (sum_p or sum_qi) else None
        fp_cap=sum_p/math.sqrt(sum_p**2+sum_qc**2) if sum_p is not None and sum_qc is not None and (sum_p or sum_qc) else None
        numex=sum((qi.get(h,0)>0.5*p.get(h,0)) for h in range(24) if h in qi and h in p)
        numpf=sum((p.get(h,0)>0 and p[h]/math.hypot(p[h],qi[h])<0.90) for h in range(24) if h in qi and h in p)
        caphours=sum(qc.get(h,0)>0 for h in range(24) if h in qc)
        alert=[]
        if sum_qpi is not None and sum_qpi>0:alert.append('REACTIVA_INDUCTIVA_PENALIZADA_ENEL')
        if numex>0:alert.append('EXCESO_INDUCTIVO_HORARIO')
        if fp is not None and fp<.90:alert.append('FP_IND_DIARIO_BAJO_090')
        elif fp is not None and fp<.95:alert.append('FP_IND_DIARIO_PREVENTIVO')
        if caphours>0:alert.append('REACTIVA_CAPACITIVA_MEDIDA_NIVEL_TENSION_PENDIENTE')
        if problems:alert.append('CALIDAD_PENDIENTE')
        lhour=max((h for h,val in p.items() if val>0),default=None)
        r={'FECHA':date,'CUENTA':acct,'SUBESTACION':accmap[acct]['etiqueta'],'PLANTA':accmap[acct]['planta'],'FRONTERA':accmap[acct]['frontera'],
           'ACTIVA_KWH':maybe_float(sum_p,2),'QI_KVARH':maybe_float(sum_qi,2),'QC_KVARH':maybe_float(sum_qc,2),
           'Q_INDUCTIVA_PENALIZADA_KVARH':maybe_float(sum_qpi,2),'FP_INDUCTIVO_DIARIO':maybe_float(fp,5),
           'FP_CAPACITIVO_DIARIO_INDICADOR':maybe_float(fp_cap,5),'HORAS_INDUCTIVAS_EXCESO':numex,'HORAS_FP_BAJO_090':numpf,
           'HORAS_CAPACITIVAS':caphours,'RATIO_QI_P':maybe_float(sum_qi/sum_p,5) if sum_p is not None and sum_qi is not None and sum_p>0 else '',
           'ALERTA':' | '.join(alert) or 'SIN_ALERTA','CALIDAD':' | '.join(problems) or 'OK_24_HORAS',
           'VERSION':'R045','DESCARGA_LOCAL':timestamp,'ULTIMA_HORA_INFERIDA':lhour if lhour is not None else ''}
        control.append(r)
        if problems:incomplete.append(r)
        if complete:
            for st,key,unit in VAR_TYPES:
                long.append({'FECHA':date,'CUENTA':acct,'ID_VARIABLE':f'ENEL_{st}_{accmap[acct]["etiqueta"].replace(" ","_")}',
                             'NOMBRE_VARIABLE':f'{st} {accmap[acct]["etiqueta"]}', 'VALOR':r[key], 'UNIDAD':unit,
                             'CALIDAD':r['CALIDAD'],'ALERTA':r['ALERTA'],'FUENTE_SHA256':source_sha,'DESCARGA_LOCAL':timestamp})
    cf=output/'ENEL_DIARIO_CONTROL.csv';write_csv(cf,control,FIELDS)
    lf=output/'ENEL_NUEVE_VARIABLES_LECTURAS.csv';write_csv(lf,long,['FECHA','CUENTA','ID_VARIABLE','NOMBRE_VARIABLE','VALOR','UNIDAD','CALIDAD','ALERTA','FUENTE_SHA256','DESCARGA_LOCAL'])
    hf=output/'ENEL_HORARIO_AUDITORIA.csv';write_csv(hf,horas,['FECHA','CUENTA','SUBESTACION','HORA','ACTIVA_KWH','QI_KVARH','QC_KVARH','Q_INDUCTIVA_PENALIZADA_REPORTADA_KVARH','FP_INDUCTIVO_HORARIO_INDICADOR','SOBRE_50_QI_P','EXCESO_ESTIMADO_QI_KVARH'])
    months=defaultdict(lambda: {'kwh':0.,'qi':0.,'qc':0.,'qpi':0.,'dias':0,'horas_exceso':0})
    for r in control:
        m=months[(r['CUENTA'],r['FECHA'][:7])]
        if r['CALIDAD'].startswith('ACTIVA_SIN_24') or r['ACTIVA_KWH']=='': continue
        m['kwh']+=r['ACTIVA_KWH'];m['qi']+=r['QI_KVARH'] if r['QI_KVARH']!='' else 0
        m['qc']+=r['QC_KVARH'] if r['QC_KVARH']!='' else 0
        m['qpi']+=r['Q_INDUCTIVA_PENALIZADA_KVARH'] if r['Q_INDUCTIVA_PENALIZADA_KVARH']!='' else 0
        m['dias']+=1;m['horas_exceso']+=r['HORAS_INDUCTIVAS_EXCESO']
    invoices=load_invoices(output/'ENEL_FACTURAS_HISTORICAS.csv')
    monthly=[]
    for (acct,mon),stats in sorted(months.items(),key=lambda x:(x[0][1],x[0][0])):
        inv=invoices.get((acct,mon),{})
        def billing(k):
            val=inv.get(k,'')
            if not val:return ''
            try:return float(val.replace(',','.'))
            except Exception:return ''
        price=billing('TARIFA_KWH_COP')
        fixed=billing('CARGO_FIJO_COP');sancprice=billing('TARIFA_PENALIZADA_COP_KVARH')
        source_rate=mon if price!='' else ''
        if price=='':
            prev=[(m, v) for (c,m),v in invoices.items() if c==acct and m<mon and v.get('TARIFA_KWH_COP','').strip()]
            if prev:
                best_month,past=max(prev,key=lambda x:x[0]);source_rate=best_month
                try:price=float(past['TARIFA_KWH_COP'].replace(',','.'))
                except Exception:price=''
                if sancprice=='':
                    try:sancprice=float(past['TARIFA_PENALIZADA_COP_KVARH'].replace(',','.'))
                    except Exception:sancprice=''
                if fixed=='':
                    try:fixed=float(past['CARGO_FIJO_COP'].replace(',','.'))
                    except Exception:fixed=''
        
        # Solo como escenario si tarifas completas y coincidencia exacta de vigencia.
        can_estimate=price!='' and (stats['qpi']==0 or sancprice!='')
        variable_energy=(stats['kwh']*price + (stats['qpi']*sancprice if sancprice!='' else 0)) if can_estimate else ''
        forecast=(variable_energy + (fixed if fixed!='' else 0)) if can_estimate else ''
        ym=download_date.strftime('%Y-%m');num_days=calendar.monthrange(int(mon[:4]),int(mon[5:7]))[1]
        predicted=(variable_energy*num_days/stats['dias']+(fixed if fixed!='' else 0)) if can_estimate and mon==ym and stats['dias'] else ''
        nt=str(accmap[acct].get('nivel_tension') or '').strip().upper()
        cap_ratio={'I':0.50,'II':0.50,'III':0.33,'IV':0.20}.get(nt)
        cap_ratio_actual=stats['qc']/stats['kwh'] if stats['kwh'] else None
        cap_alert=('NIVEL_TENSION_PENDIENTE' if cap_ratio is None else
                   'REVISAR_EXCESO_CAPACITIVO_EN_PERIODO' if cap_ratio_actual is not None and cap_ratio_actual>cap_ratio else
                   'DENTRO_REFERENCIA_RATIO_CAPACITIVO')
        monthly.append({'PERIODO':mon,'CUENTA':acct,'SUBESTACION':accmap[acct]['etiqueta'],
                        'DIAS_REPORTADOS':stats['dias'],'ENERGIA_ACTIVA_KWH':round(stats['kwh'],2),
                        'QI_KVARH':round(stats['qi'],2),'QC_KVARH':round(stats['qc'],2),
                        'R_PENALIZADA_ENEL_KVARH':round(stats['qpi'],2),'HORAS_EXCESO_INDUCTIVO':stats['horas_exceso'],
                        'NIVEL_TENSION':nt or 'PENDIENTE','RATIO_QC_P_MENSUAL':round(cap_ratio_actual,5) if cap_ratio_actual is not None else '',
                        'UMBRAL_CAPACITIVO_RATIO':cap_ratio if cap_ratio is not None else '',
                        'ALERTA_CAPACITIVA_MES':cap_alert,
                        'TARIFA_KWH_COP':price,'TARIFA_PENALIZADA_COP_KVARH':sancprice,'TARIFA_REFERENCIA_MES':source_rate, 'PRONOSTICO_CIERRE_MES_PARCIAL_COP':round(predicted,2) if predicted!='' else '',
                        'FACTURA_ENEL_TOTAL_COP':billing('FACTURA_ENEL_TOTAL_COP'),
                        'ESTIMACION_PARCIAL_COP_SIN_OTROS_CARGOS':round(forecast,2) if forecast!='' else '',
                        'NOTA':'ESTIMACION NO ES FACTURA; faltan cargos, impuestos y condiciones contractuales'})
    write_csv(output/'ENEL_MENSUAL_COSTOS_CONCILIACION.csv',monthly,['PERIODO','CUENTA','SUBESTACION','DIAS_REPORTADOS','ENERGIA_ACTIVA_KWH','QI_KVARH','QC_KVARH','R_PENALIZADA_ENEL_KVARH','HORAS_EXCESO_INDUCTIVO','NIVEL_TENSION','RATIO_QC_P_MENSUAL','UMBRAL_CAPACITIVO_RATIO','ALERTA_CAPACITIVA_MES','TARIFA_KWH_COP','TARIFA_PENALIZADA_COP_KVARH','TARIFA_REFERENCIA_MES','PRONOSTICO_CIERRE_MES_PARCIAL_COP','FACTURA_ENEL_TOTAL_COP','ESTIMACION_PARCIAL_COP_SIN_OTROS_CARGOS','NOTA'])
    if not (output/'ENEL_FACTURAS_HISTORICAS.csv').exists():
        invoice_rows=[{'CUENTA':acct,'PERIODO':month,'FECHA_INICIO_FACTURA':'','FECHA_FIN_FACTURA':'','TARIFA_KWH_COP':'',
                       'TARIFA_PENALIZADA_COP_KVARH':'','CARGO_FIJO_COP':'','FACTURA_ENEL_TOTAL_COP':'','REACTIVA_COBRADA_COP':'',
                       'NUMERO_FACTURA':'','ESTADO_VALIDACION':'PENDIENTE_DOCUMENTO'} for (acct,month) in sorted(months)]
        write_csv(output/'ENEL_FACTURAS_HISTORICAS.csv',invoice_rows,['CUENTA','PERIODO','FECHA_INICIO_FACTURA','FECHA_FIN_FACTURA','TARIFA_KWH_COP','TARIFA_PENALIZADA_COP_KVARH','CARGO_FIJO_COP','FACTURA_ENEL_TOTAL_COP','REACTIVA_COBRADA_COP','NUMERO_FACTURA','ESTADO_VALIDACION'])
    revisions=db.execute('SELECT count(*) FROM revisiones').fetchone()[0]
    status={'version':'R045_CANDIDATO','source_file':target.name,'source_sha256':source_sha,
            'fecha_descarga_local':timestamp,'hora_descarga_conocida':download_known,
            'fecha_corte_operativa':cutoff,'fecha_maxima_publicable':max([r['FECHA'] for r in control],default=''),
            'max_fecha_enel_fuente':max([dmy(row[1]) for row in data['Activa']],default=''),
            'total_dias_contrato':len(control),'dias_con_observaciones':len(incomplete),
            'cuentas':sorted(accmap.keys()),'variables_activas':len(set(x['ID_VARIABLE'] for x in long)),
            'filas_nueve_variables':len(long),'filas_horarias':len(horas),
            'actualizaciones_horarias':changes,'versiones_antiguas_rechazadas':older_skipped,'auditoria_revisiones_historicas':revisions,
            'totales_enel_no_coinciden_hora':total_diff,'cuentas_no_configuradas':sorted(unknown),
            'ultimas_fechas':{ac:max((r['FECHA'] for r in control if r['CUENTA']==ac),default='') for ac in accmap},
            'advertencia':'FP diario es indicador energetico, no sustituye criterio horario ni factura. Reactiva capacitiva no equivale a cobro confirmado.'}
    (output/'ENEL_METADATOS_CONTROL.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
    (output/'ENEL_DASHBOARD_PRIVATE.json').write_text(json.dumps({'meta':status,'diarios':control,'mensuales':monthly},ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    db.commit();db.close()
    print(json.dumps(status,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
