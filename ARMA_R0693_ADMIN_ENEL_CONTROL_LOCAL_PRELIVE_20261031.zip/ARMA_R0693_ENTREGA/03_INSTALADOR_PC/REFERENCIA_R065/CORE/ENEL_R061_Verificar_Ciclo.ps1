﻿# ARMA R064.1 - preflight del agente R061. NO descarga ni escribe datos.
# FIX: PowerShell Windows elimina comillas internas de -c/-e. Python AST bytes, Node modulo via entorno temporal.
param([string]$Root='C:\ARMA_ENEL_R046')
$ErrorActionPreference='Stop'
$needed=@('enel-r046.mjs','ENEL_R061_Ciclo_Automatico.ps1',
 'ENEL_R061_Procesar_Enviar.py','ENEL_R050_Leer_Clave_DPAPI.ps1',
 'R045_PROCESAR_COPIA_R050.py','R045_Config_CONCILIADO_R050.json',
 'ENEL_R050_Config.json','ENEL_R064_Resolver_Entorno.ps1')
$missing=@($needed|Where-Object{-not(Test-Path -LiteralPath (Join-Path $Root $_) -PathType Leaf)})
if($missing.Count){Write-Host ('R064_FALTAN_COMPONENTES: '+($missing -join ', '));exit 2}
try{$cfg=Get-Content -LiteralPath (Join-Path $Root 'ENEL_R050_Config.json') -Raw|ConvertFrom-Json}catch{Write-Host 'R064_CONFIG_RECEPTOR_INVALIDA';exit 3}
if([string]$cfg.receiverUrl -notmatch '^https://script\.google\.com/macros/s/[A-Za-z0-9_-]+/exec$'){
 Write-Host 'R064_URL_RECEPTOR_PENDIENTE. Use ENEL_R061_Configurar_Receptor.ps1 SIN cambiar las claves.';exit 4
}
$dpapi=Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R046\secrets\enel_ingesta_r050.dpapi'
if(!(Test-Path -LiteralPath $dpapi -PathType Leaf)){
 Write-Host 'R064_HMAC_DPAPI_AUSENTE: NO confundir con contraseña del portal ENEL.';exit 5
}
. (Join-Path $Root 'ENEL_R064_Resolver_Entorno.ps1')
$runtime=ARMA_R064_GetRuntime -Root $Root
if(!$runtime){exit 6}
try{
 & $runtime.Node --check (Join-Path $Root 'enel-r046.mjs')
 if($LASTEXITCODE -ne 0){Write-Host 'R064_NODE_JS_SINTAXIS_ERROR';exit 7}
 $argsPython=@($runtime.PythonArgs)
 & $runtime.Python @argsPython -c 'import ast,sys,pathlib;[ast.parse(pathlib.Path(p).read_bytes()) for p in sys.argv[1:]]' (Join-Path $Root 'ENEL_R061_Procesar_Enviar.py') (Join-Path $Root 'R045_PROCESAR_COPIA_R050.py')
 if($LASTEXITCODE -ne 0){Write-Host 'R064_PYTHON_SINTAXIS_ERROR';exit 8}
 Push-Location $Root
 try{
   # R064.1: PowerShell 5.1 puede perder comillas internas al invocar node -e.
   # Pasamos el nombre del modulo por variable de entorno de este proceso.
   $previousProbe=[Environment]::GetEnvironmentVariable('ARMA_R064_PROBE_MODULE','Process')
   try{
     $env:ARMA_R064_PROBE_MODULE='playwright'
     & $runtime.Node -e 'require.resolve(process.env.ARMA_R064_PROBE_MODULE)'
     $moduleExit=$LASTEXITCODE
   }finally{
     if($null -eq $previousProbe){Remove-Item -Path 'Env:ARMA_R064_PROBE_MODULE' -ErrorAction SilentlyContinue}
     else{$env:ARMA_R064_PROBE_MODULE=$previousProbe}
   }
   if($moduleExit -ne 0){Write-Host 'R064_FALTA_PLAYWRIGHT: dependencia del descargador R047';exit 9}
   Write-Host 'R064_PLAYWRIGHT_OK' 
 }finally{Pop-Location}
 Write-Host 'LOCAL_LISTO_R064: precondiciones verificadas. AUN falta probar descarga e ingesta reales.'
 exit 0
}catch{Write-Host ('R064_ERROR_PRECONDICION: '+$_.Exception.GetType().Name);exit 10}
