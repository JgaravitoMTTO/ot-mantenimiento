﻿# R061: provisionar MISMA clave HMAC ya guardada en DPAPI; no rotar ni mostrar.
# Ejecutar en el mismo usuario Windows que genero el archivo DPAPI.
$ErrorActionPreference='Stop'
$reader='C:\ARMA_ENEL_R046\ENEL_R050_Leer_Clave_DPAPI.ps1'
if(!(Test-Path -LiteralPath $reader)){throw 'LECTOR_DPAPI_NO_ENCONTRADO'}
$key=(& powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $reader)
if($LASTEXITCODE -ne 0 -or $key -notmatch '^[a-f0-9]{64}$'){throw 'CLAVE_DPAPI_NO_DISPONIBLE'}
try {Set-Clipboard -Value $key;Write-Host 'CLAVE EXISTENTE COPIADA AL PORTAPAPELES; pegela SOLO en propiedades del receptor.'}
finally {$key=$null}
Write-Host 'Al terminar, limpiar con Set-Clipboard -Value "".'
