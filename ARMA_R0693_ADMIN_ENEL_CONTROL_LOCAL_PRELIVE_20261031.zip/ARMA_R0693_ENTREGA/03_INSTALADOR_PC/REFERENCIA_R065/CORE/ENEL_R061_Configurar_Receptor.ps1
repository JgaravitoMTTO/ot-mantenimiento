# ARMA R054 - configura SOLO URL receptor /exec, nunca una contraseña ni token.
param([string]$Root='C:\ARMA_ENEL_R046')
$ErrorActionPreference='Stop'
$cfg=Join-Path $Root 'ENEL_R050_Config.json'
if(!(Test-Path -LiteralPath $cfg)){throw 'FALTA_CONFIG: primero instale los componentes R054.'}
Write-Host 'Pegue SOLO la URL /exec del proyecto RECEPTOR AISLADO ENEL (no Backend ARMA).'
$url=Read-Host 'URL receptor de ingesta'
if($url -notmatch '^https://script\.google\.com/macros/s/[A-Za-z0-9_-]+/exec$'){
 throw 'URL_RECEPTOR_INVALIDA: se requiere https://script.google.com/macros/s/.../exec, sin ? ni #.'
}
# Archivo no contiene secreto; se mantiene para el mismo usuario de Windows.
$obj=@{receiverUrl=$url}
$json=$obj|ConvertTo-Json -Compress
$temp=$cfg+'.tmp'
[IO.File]::WriteAllText($temp,$json,[Text.UTF8Encoding]::new($false))
Move-Item -LiteralPath $temp -Destination $cfg -Force
Write-Host 'RECEPTOR CONFIGURADO. No se han enviado credenciales.'
Write-Host 'Ahora verifique el ciclo y configure el HMAC en Apps Script separado.'
