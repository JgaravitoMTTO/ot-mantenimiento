# R050 — ejecutar INTERACTIVAMENTE bajo el MISMO usuario Windows del robot.
# Genera 256 bits aleatorios, cifra DPAPI CurrentUser. Nunca muestra la clave en consola.
# Copia la clave HEX al portapapeles para pegarla UNICAMENTE en las Propiedades del
# proyecto Apps Script RECEPTOR, clave ENEL_R050_HMAC_KEY_HEX.
# Limpie el portapapeles al concluir, no comparta la clave ni la adjunte a chats.
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Security
$dir=Join-Path $env:LOCALAPPDATA 'ARMA_ENEL_R046\secrets'
$file=Join-Path $dir 'enel_ingesta_r050.dpapi'
[System.IO.Directory]::CreateDirectory($dir)|Out-Null
if(Test-Path -LiteralPath $file){
  Write-Host 'YA EXISTE CLAVE DPAPI. NO SE ROTARA AUTOMATICAMENTE.'
  throw 'PROVISION_EXISTENTE: conservar la misma clave o ejecutar rotacion formal por separado.'
}
$buf=New-Object byte[] 32
$rng=[System.Security.Cryptography.RandomNumberGenerator]::Create()
try{$rng.GetBytes($buf)}finally{$rng.Dispose()}
$key=([BitConverter]::ToString($buf)).Replace('-','').ToLowerInvariant()
[Array]::Clear($buf,0,$buf.Length)
$data=[Text.Encoding]::UTF8.GetBytes($key)
$cypher=[System.Security.Cryptography.ProtectedData]::Protect($data,$null,[System.Security.Cryptography.DataProtectionScope]::CurrentUser)
[IO.File]::WriteAllBytes($file,$cypher)
[Array]::Clear($data,0,$data.Length)
$sid=[System.Security.Principal.WindowsIdentity]::GetCurrent().User
$sys=New-Object System.Security.Principal.SecurityIdentifier 'S-1-5-18'
$acl=New-Object System.Security.AccessControl.FileSecurity
$acl.SetAccessRuleProtection($true,$false)
$acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($sid,'FullControl','Allow')))
$acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($sys,'FullControl','Allow')))
[IO.File]::SetAccessControl($file,$acl)
Set-Clipboard -Value $key
$key=$null
Write-Host 'CLAVE CIFRADA. COPIADA AL PORTAPAPELES TEMPORALMENTE.'
Write-Host 'Pegue ahora en Apps Script receptor: ENEL_R050_HMAC_KEY_HEX; despues BORRE portapapeles con Set-Clipboard -Value "".'
