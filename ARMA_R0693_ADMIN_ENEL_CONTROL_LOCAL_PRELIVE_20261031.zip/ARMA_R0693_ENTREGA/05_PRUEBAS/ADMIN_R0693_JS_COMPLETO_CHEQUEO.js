
const API="https://script.google.com/macros/s/AKfycbyuMMeKzICtFnCnMA3xfmBj9hR1KHklRXytrod5Cj6FVOjjUBrem6bf7JW_Omd68X1FEQ/exec";
const el=id=>document.getElementById(id);
let activeGroup='TODOS',lastData=null,dpBusy=false,dpTimer=null,jobTimer=null,jobBusy=false,legacyOpen=false;
function token(){return localStorage.getItem('ARMA_TOKEN')||sessionStorage.getItem('ARMA_TOKEN')||(()=>{try{return JSON.parse(localStorage.getItem('ARMA_SESSION_CACHE')||'{}').token||''}catch(e){return''}})()}
async function api(action,data={},timeoutMs=60000){const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),timeoutMs);try{const r=await fetch(API,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify(Object.assign({action,token:token()},data)),signal:ctrl.signal});if(!r.ok)throw new Error('HTTP_'+r.status);const j=await r.json();if(!j.ok)throw new Error(j.detail||j.error||'ERROR_BACKEND');return j;}catch(err){if(err.name==='AbortError')throw new Error('BACKEND_SUPERÓ_TIEMPO_DE_RESPUESTA');throw err;}finally{clearTimeout(timer)}}
const esc=v=>{const d=document.createElement('span');d.textContent=String(v==null?'':v);return d.innerHTML};
const fmt=v=>v?esc(v):'—';
const showState=(msg,level='')=>{el('dpStatus').className='status '+level;el('dpStatusText').textContent=msg};
function modal(title,text,ask=false){return new Promise(resolve=>{el('modalTitle').textContent=title;el('modalText').textContent=text;el('modalCancel').classList.toggle('hidden',!ask);el('armaModal').classList.remove('hidden');const done=v=>{el('armaModal').classList.add('hidden');el('modalAccept').onclick=null;el('modalCancel').onclick=null;resolve(v)};el('modalAccept').onclick=()=>done(true);el('modalCancel').onclick=()=>done(false);el('modalAccept').focus()})}
function levelClass(l){return l==='PUBLICACION_REGISTRADA'?'good':l==='REVISAR'?'bad':'warn'}
function levelText(l){return {'PUBLICACION_REGISTRADA':'LOTE REGISTRADO','SIN_CONFIRMACION_RECIENTE':'SIN CONFIRMACIÓN RECIENTE','SIN_EVIDENCIA':'SIN EVIDENCIA EN MUESTRA','REVISAR':'VERIFICAR ANOMALÍA'}[l]||l}
function renderRows(){if(!lastData)return;const rows=(lastData.datasets||[]).filter(x=>activeGroup==='TODOS'||x.group===activeGroup);el('dpRows').innerHTML=rows.map(x=>{const klass=!x.exists||x.status==='ULTIMO_LOTE_CON_ERROR'?'bad':x.last?'good':'warn';const info=x.last?x.last.read+' / '+x.last.inserted+' / '+x.last.updated:'—';const link=x.sheetUrl?'<a class="open-table" target="_blank" rel="noopener noreferrer" href="'+esc(x.sheetUrl)+'">ABRIR TABLA</a>':'<span class="subcell">VER LIBRO DATAPEL</span>';return '<tr><td><b>'+esc(x.group)+'</b><br>'+esc(x.dataset)+'<div class="subcell">'+esc(x.sheet||'')+'</div></td><td>'+fmt(x.last&&x.last.at)+'</td><td>'+fmt(x.lastOk&&x.lastOk.at)+'</td><td class="num">'+Number(x.physicalRows||0).toLocaleString('es-CO')+(x.latestWrittenSample?'<div class="subcell">MUESTRA FECHA_SYNC: '+fmt(x.latestWrittenSample)+'</div>':'')+(x.latestSourceDateSample?'<div class="subcell">ORIGEN EN MUESTRA: '+fmt(x.latestSourceDateSample)+'</div>':'')+'</td><td>'+esc(info)+'</td><td><span class="pill '+klass+'">'+esc(x.status)+'</span></td><td>'+link+'</td></tr>'}).join('')||'<tr><td colspan="7">SIN TABLAS EN ESTE FILTRO</td></tr>'}
function render(j){lastData=j;let warnings=(j.groups||[]).filter(x=>x.level!=='PUBLICACION_REGISTRADA').length;el('kDatasets').textContent=(j.datasets||[]).length;el('kBatches').textContent=Number(j.analyzedSyncRows||0).toLocaleString('es-CO');el('kWarnings').textContent=warnings;el('kErrors').textContent=(j.errors||[]).length;el('kTime').textContent=String(j.generatedAt||'').slice(11,19)||'—';let msg='CONSULTA REALIZADA · '+j.generatedAt+' · '+j.analyzedSyncRows+' LOTES DE '+j.syncLogRows+' REGISTRADOS';if(warnings)msg+=' · '+warnings+' FLUJO(S) A REVISAR';if(!j.detailLinksVerified)msg+=' · CONTRATO R035 COMPATIBLE';showState(msg,warnings?'warn':'good');el('dpGroups').innerHTML=(j.groups||[]).map(g=>'<div class="source '+levelClass(g.level)+'"><h4>'+esc(g.label)+'</h4><span class="signal">'+esc(levelText(g.level))+'</span><small>ÚLTIMO LOTE: <b>'+fmt(g.last&&g.last.at)+'</b></small><small>ÚLTIMO EXITOSO: <b>'+fmt(g.lastOk&&g.lastOk.at)+'</b></small><small>EDAD: '+(g.ageHours==null?'—':g.ageHours+' H')+' · UMBRAL ORIENTATIVO: '+(g.maxHours?g.maxHours+' H':'SIN UMBRAL')+'</small><small>TABLAS AUSENTES: '+g.missingSheets+' · ÚLTIMO ERROR: '+g.erroredDatasets+'</small></div>').join('');renderRows();el('dpHistory').innerHTML=(j.recent||[]).map(x=>'<tr><td>'+fmt(x.at)+'</td><td>'+esc(x.dataset)+'</td><td><span class="pill '+(x.errors>0||['FAILED','PARTIAL','ERROR'].includes(x.status)?'bad':'good')+'">'+esc(x.status)+'</span></td><td>'+x.read+'</td><td>'+x.inserted+'</td><td>'+x.updated+'</td><td>'+x.errors+'</td></tr>').join('')||'<tr><td colspan="7">SIN LOTES EN LA MUESTRA</td></tr>';el('dpExport').disabled=false;}
async function loadDatapel(force=false){if(dpBusy)return;dpBusy=true;el('dpRefresh').disabled=true;el('dpRefresh').innerHTML='<span class="spin"></span> CONSULTANDO';showState('CONSULTANDO RECEPTOR DATAPEL Y TABLAS...');try{let j;try{j=await api('armaAdminDatapelHealthR036',{force:force===true},60000)}catch(e){if(/ACCION_NO_RECONOCIDA|not recognized|unknown action/i.test(e.message)){j=await api('armaAdminDatapelHealth',{force:force===true},60000)}else throw e}render(j)}catch(e){showState('ERROR DE CONSULTA: '+(e.message||e)+(lastData?' · CONSERVANDO ÚLTIMA LECTURA':' · SIN DATOS VERIFICADOS'),'bad')}finally{dpBusy=false;el('dpRefresh').disabled=false;el('dpRefresh').textContent='VERIFICAR AHORA';clearTimeout(dpTimer);dpTimer=setTimeout(()=>{if(document.visibilityState==='visible')loadDatapel(false);else dpTimer=setTimeout(()=>loadDatapel(false),120000)},120000)}}
function exportCsv(){if(!lastData)return;const q=v=>'"'+String(v==null?'':v).replace(/"/g,'""')+'"';const header=['GRUPO','DATASET','HOJA','ULTIMO_LOTE','ULTIMO_EXITO','ESTADO','FILAS','LEIDOS','INSERTADOS','ACTUALIZADOS','ERRORES','URL_TABLA'];const rows=(lastData.datasets||[]).map(x=>[x.group,x.dataset,x.sheet,x.last&&x.last.at,x.lastOk&&x.lastOk.at,x.status,x.physicalRows,x.last&&x.last.read,x.last&&x.last.inserted,x.last&&x.last.updated,x.last&&x.last.errors,x.sheetUrl]);const csv='\ufeff'+[header,...rows].map(x=>x.map(q).join(';')).join('\r\n');const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='ARMA_DATAPEL_AUDITORIA_'+new Date().toISOString().slice(0,10)+'.csv';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function paintJob(type,j){j=j||{};const low=type.toLowerCase(),total=Number(j.total||0),cursor=Number(j.cursor||0),pct=total?Math.min(100,Math.round(cursor*100/total)):0;el('fill'+type).style.width=pct+'%';el(low+'Cursor').textContent=cursor;el(low+'Total').textContent=total;el(low+'Ok').textContent=Number(j.generated||0);el(low+'Err').textContent=Number(j.errors||0);el('state'+type).textContent=(j.status||'IDLE')+' · '+pct+'% · RESTAN '+Math.max(0,total-cursor)+(j.engine?' · '+j.engine:'');el('live'+type).textContent=(j.running?'EN VIVO':'ÚLTIMA LECTURA')+' · CURSOR '+cursor+' / '+total+(j.lastHeartbeat?' · ÚLTIMO LOTE '+j.lastHeartbeat:'');el('btn'+type).disabled=!!j.running;el('stop'+type).disabled=!j.running}
async function refreshJobs(){if(!legacyOpen||jobBusy)return;jobBusy=true;try{const j=await api('armaAdminPdfStatus',{},45000);paintJob('OT',j.jobs&&j.jobs.OT);paintJob('BT',j.jobs&&j.jobs.BT)}catch(e){el('stateOT').textContent='BACKEND PDF NO DISPONIBLE: '+e.message}finally{jobBusy=false;clearTimeout(jobTimer);if(legacyOpen)jobTimer=setTimeout(refreshJobs,30000)}}
async function refreshDaily(){try{const j=await api('armaAdminBootstrap',{},45000);if(j.user||j.nivel)el('userPill').textContent=(j.user||'ARMA')+' // '+(j.nivel||'SUPER_ADMIN');el('dailyState').textContent=j.dailyAdvance&&j.dailyAdvance.installed?'ACTIVO · '+(j.dailyAdvance.cadence||'PROGRAMADO'):'GUARD AUTOMÁTICO NO CONFIRMADO'}catch(e){el('dailyState').textContent='CONSULTA DEL GUARD NO DISPONIBLE: '+e.message}}
async function startJob(t){const confirmed=await modal('CONFIRMAR REGENERACIÓN MASIVA','Esta operación puede volver a generar TODOS los PDF de '+t+' desde cero. ¿Deseas continuar?',true);if(!confirmed)return;try{const j=await api('armaAdminPdfStart',{type:t},45000);paintJob(t,j.job);await modal('ARMA · OPERACIÓN INICIADA','El proceso fue solicitado al Backend. La barra muestra el cursor persistente.');refreshJobs()}catch(e){await modal('ARMA · OPERACIÓN NO INICIADA',e.message)}}
async function stopJob(t){const yes=await modal('DETENER OPERACIÓN','¿Detener la regeneración '+t+'? Los archivos completados se conservan.',true);if(!yes)return;try{const j=await api('armaAdminPdfStop',{type:t},45000);paintJob(t,j.job)}catch(e){await modal('ARMA · ERROR',e.message)}}
el('filters').addEventListener('click',e=>{const b=e.target.closest('button[data-group]');if(!b)return;activeGroup=b.dataset.group;el('filters').querySelectorAll('button').forEach(x=>x.classList.toggle('active',x===b));renderRows()});
el('dpRefresh').onclick=()=>loadDatapel(true);el('dpExport').onclick=exportCsv;
el('legacy').addEventListener('toggle',()=>{legacyOpen=el('legacy').open;if(legacyOpen){refreshJobs();refreshDaily()}else clearTimeout(jobTimer)});
el('dailyRefresh').onclick=refreshDaily;el('btnOT').onclick=()=>startJob('OT');el('btnBT').onclick=()=>startJob('BT');el('stopOT').onclick=()=>stopJob('OT');el('stopBT').onclick=()=>stopJob('BT');
(async()=>{if(!token()){location.href='main.html';return}el('userPill').textContent='ARMA // CONECTANDO';await loadDatapel(false);try{const j=await api('armaAdminBootstrap',{},45000);el('userPill').textContent=(j.user||'ARMA')+' // '+(j.nivel||'SUPER_ADMIN')}catch(e){el('userPill').textContent='ARMA // SESIÓN'} })();
/* R069 ENEL: UI auxilia autenticación SUPER_ADMIN existente; jamás maneja contraseñas. */
let enelR069Allowed=false,enelR069Busy=false;
function enelR069Gate(yes){enelR069Allowed=!!yes;['enelR069Refresh','enelRotate','enelManual','enelPlan','enelGuide'].forEach(id=>{if(el(id))el(id).disabled=!yes});}
function enelR069Status(t,level=''){const e=el('enelR069State');e.textContent=t;e.className='enel-status '+level;}
async function enelR069Load(){if(!enelR069Allowed||enelR069Busy)return;enelR069Busy=true;el('enelR069Refresh').disabled=true;enelR069Status('CONSULTANDO FUENTE ENEL EN GOOGLE SHEETS...');try{const j=await api('enelAdminHealthR069',{},45000);el('enelLastIngest').textContent=j.lastAcceptedAt||'SIN INGESTA ACEPTADA';el('enelCut').textContent=j.cut||'SIN CORTE VERIFICADO';el('enelScheduler').textContent='NO VISIBLE DESDE SHEETS';const c=j.recentAccepted===true;let t='HOJA ENEL: '+(j.ingestasPresent?'DISPONIBLE':'AUSENTE')+' · INGESTAS EN REGISTRO: '+(j.ingestasTotal??'—')+'\n';t+='ÚLTIMO LOTE: '+(j.lastAcceptedAt||'SIN CONFIRMACIÓN')+' · '+(j.lastAcceptedRows??0)+' REGISTROS DE DÍAS/FRONTERAS';t+='\nSCHEDULER WINDOWS: SIN TELEMETRÍA REMOTA. REQUIERE VALIDACIÓN LOCAL EN EL SERVIDOR.';enelR069Status(t,c?'good':'bad');}catch(e){enelR069Status('MONITOR ENEL NO DISPONIBLE: '+String(e.message||e)+'\nNO INTERPRETAR COMO DESCARGA FALLIDA NI MODIFICAR OTROS SISTEMAS.','bad')}finally{enelR069Busy=false;el('enelR069Refresh').disabled=!enelR069Allowed;}}
async function enelR069Protocol(kind){if(!enelR069Allowed)return;const map={rotate:{url:'arma-enel-r0692-rotar://abrir',title:'ACTUALIZAR DPAPI LOCAL',text:'PRIMERO cambie la contraseña en el portal oficial ENEL. El botón invoca el agente local R069.3 (debe instalarse primero, solo en este PC y la misma cuenta Windows). En PowerShell ingrese usuario y contraseña vigentes de ENEL; se guardan exclusivamente en DPAPI local. Si no abre nada, instale el puente R069.3 y repita. No modifica la contraseña en el portal ni actualiza otros equipos.'},manual:{url:'arma-enel-r052://actualizar',title:'DESCARGA MANUAL EN ESTE PC',text:'Activa el protocolo R052 instalado en ESTA cuenta Windows. Confirme la operación en el equipo local; después verifique la ingesta y el corte ENEL.'},program:{url:'arma-enel-r069-programar://abrir',title:'PROGRAMAR EN ESTE SERVIDOR',text:'Solo desde el computador servidor, con su cuenta Windows ENEL y después de una descarga manual integral exitosa. Se solicitará confirmación local y contraseña de WINDOWS. No se instalará ninguna tarea a distancia.'}};const x=map[kind];if(!x)return;const yes=await modal(x.title,x.text+'\n\n¿ABRIR PROTOCOLO LOCAL?',true);if(!yes)return;const a=document.createElement('a');a.href=x.url;a.style.display='none';document.body.appendChild(a);a.click();a.remove();}
async function enelR069Guide(){await modal('NET · ENEL R069.3 · PC / SERVIDOR','1. Para cambiar clave en este PC: instalar primero el PUENTE LOCAL R069.3 con ENEL_R0693_Instalar_Boton_Clave.ps1 -Instalar, bajo la cuenta Windows que usa ENEL.\n2. En el PC servidor instalar R065 CORE conservador (sin sobrescribir R047) y scripts R069; no copiar .dpapi.\n3. Aprovisionar DPAPI de ENEL y HMAC receptor por canal secreto autorizado bajo MISMA cuenta Windows ejecutora.\n4. Probar R064.1 y ejecutar descarga+ingesta R061 manual.\n5. El puente de cambio de clave R069.3 NO instala el scheduler. Para programación futura en servidor siga la guía R069 completa y valide previamente el ciclo. No confundir ambas instalaciones.\n6. Comprobar Task Scheduler y el corte/ingesta en esta página.\nNo es posible instalar tareas Windows desde HTML de GitHub Pages sin agente local; tampoco se deben publicar claves en Drive.');}
el('enelR069Refresh').onclick=()=>enelR069Load();el('enelRotate').onclick=()=>enelR069Protocol('rotate');el('enelManual').onclick=()=>enelR069Protocol('manual');el('enelPlan').onclick=()=>enelR069Protocol('program');el('enelGuide').onclick=enelR069Guide;
(async()=>{try{if(!token())return;const j=await api('armaAdminBootstrap',{},45000);if(!j||j.ok!==true||String(j.nivel||'').toUpperCase()!=='SUPER_ADMIN'){enelR069Status('SOLO SUPER_ADMIN ARMA PUEDE CONSULTAR ESTE PANEL.','bad');return;}enelR069Gate(true);await enelR069Load();}catch(err){enelR069Status('PERMISO NO VALIDADO: '+String(err.message||err),'bad')}})();
/* A.R.D.A.N. R069.3 - Panel ENEL en Administrar ARMA.
   Sin secretos. Acciones locales fijas. Backend R069.1 permanece intacto. */
(function(){
 'use strict';
 const paquete='ARMA_ENEL_R0693_INSTALADOR_PC.zip';
 const acciones={
  clave:{scheme:'arma-enel-r0693-clave://abrir',titulo:'ACTUALIZAR CLAVE ENEL · ESTE PC',descripcion:'Primero cambiar la clave en el portal oficial ENEL y probar el acceso. Después el agente local solicitará la credencial, sin enviarla a ARMA web. Solo actualiza DPAPI del usuario Windows actual.'},
  manual:{scheme:'arma-enel-r0693-manual://abrir',titulo:'DESCARGA MANUAL ENEL · ESTE PC',descripcion:'Ejecuta el verificador R061 y el ciclo local de descarga + ingesta. Requiere Node, Python, Playwright, receptor HMAC y credencial DPAPI correctamente configurados.'},
  activar:{scheme:'arma-enel-r0693-activar://abrir',titulo:'ACTIVAR AUTOMÁTICA · ESTE PC',descripcion:'Crea o habilita la tarea local ARMA_ENEL_R065_DIARIO a las 03:30 solo después de una descarga manual reciente OK. La primera creación solicita la contraseña de WINDOWS en una consola local. No cambia tareas en otros computadores.'},
  desactivar:{scheme:'arma-enel-r0693-desactivar://abrir',titulo:'DESHABILITAR AUTOMÁTICA · ESTE PC',descripcion:'Deshabilita futuras ejecuciones de la tarea diaria ENEL del computador donde está abierto ARMA. No detiene una descarga ya en marcha ni afecta otras tareas.'},
  estado:{scheme:'arma-enel-r0693-estado://abrir',titulo:'ESTADO DEL AGENTE · ESTE PC',descripcion:'Abre un diagnóstico local de identidad Windows, DPAPI, tarea programada y último resultado R061. No equivale al estado remoto del servidor.'}
 };
 const qs=(s)=>document.querySelector(s);
 async function autorizado(){
  if(typeof api!=='function'||typeof token!=='function'||!token())throw Error('INICIA SESIÓN EN MAIN');
  const j=await api('armaAdminBootstrap',{},45000);
  if(String(j.nivel||'').toUpperCase()!=='SUPER_ADMIN')throw Error('ACCESO EXCLUSIVO SUPER_ADMIN');
  return true;
 }
 async function dialogo(t,detalle,confirmar){
  if(typeof modal==='function')return modal(t,detalle,!!confirmar);
  return confirmar?window.confirm(t+'\n'+detalle):(window.alert(t+'\n'+detalle),true);
 }
 function abrirProtocolo(url){
  const link=document.createElement('a');link.href=url;link.style.display='none';
  document.body.appendChild(link);link.click();link.remove();
 }
 async function ejecutar(tipo){
  try{
   await autorizado();
   const a=acciones[tipo];if(!a)throw Error('ACCIÓN DESCONOCIDA');
   const si=await dialogo(a.titulo,a.descripcion+'\n\nRequiere instalar previamente el agente local R069.3 en ESTE PC y con el mismo usuario Windows del robot.\n¿ABRIR CONTROL LOCAL?',true);
   if(si)abrirProtocolo(a.scheme);
  }catch(e){await dialogo('ARMA ENEL · NO INICIADO',String(e.message||e),false)}
 }
 async function instalar(){
  try{
   await autorizado();
   const ok=await dialogo('INSTALAR ARMA ENEL · ESTE PC','El navegador descargará un archivo ZIP. Por restricciones de Windows, ninguna web puede instalar PowerShell o Task Scheduler silenciosamente.\n\nPASOS: 1) Extraer en DESCARGAS; 2) abrir la carpeta extraída; 3) ejecutar 01_INSTALAR_EN_ESTE_PC.cmd; 4) escribir INSTALAR en consola. El puente quedará registrado para el usuario Windows actual.\n\nLos archivos originales R047/R061 no se sobrescriben. ¿DESCARGAR INSTALADOR?',true);
   if(!ok)return;
   const probe=await fetch(paquete,{method:'HEAD',cache:'no-store'});
   if(!probe.ok)throw Error('ZIP NO PUBLICADO EN GITHUB PAGES: falta copiar '+paquete+' al repositorio y publicarlo.');
   const a=document.createElement('a');a.href=paquete;a.download=paquete;document.body.appendChild(a);a.click();a.remove();
  }catch(e){await dialogo('INSTALADOR NO DISPONIBLE',String(e.message||e),false)}
 }
 async function guia(){
  await dialogo('ENEL R069.3 · USO EN CUALQUIER PC','1. INSTALAR EN ESTE PC: descarga ZIP y exige una sola ejecución local de 01_INSTALAR_EN_ESTE_PC.cmd.\n2. Antes de usar descargas: configurar credenciales ENEL vía DPAPI, clave HMAC del receptor y dependencias Node/Python/Playwright EN ESTE usuario Windows.\n3. CAMBIAR CLAVE: primero cambiar y probar en portal ENEL; luego actualizar DPAPI desde la página.\n4. DESCARGA MANUAL: correr ciclo R061, confirmar recepción real en Sheets.\n5. ACTIVAR: crea o habilita tarea local, previa descarga OK.\n6. DESHABILITAR: inhabilita tarea local, preserva configuración.\n7. ESTADO: muestra información de ESTE PC.\nIMPORTANTE: Abrir esta página en PC distinto NO permite controlar un servidor remoto. Para eso se requiere un agente permanente en el servidor y una cola autenticada de órdenes por HTTPS saliente.',false);
 }
 function init(){
  const panel=qs('#enelR069'),buttons=qs('#enelR069 .enel-actions');
  if(!panel||!buttons||document.getElementById('enelR0693Instalar'))return;
  const add=(id,texto,cls,callback)=>{
   const b=document.createElement('button');b.type='button';b.id=id;b.className='btn '+cls;b.textContent=texto;
   b.onclick=callback;buttons.appendChild(b);
  };
  add('enelR0693Instalar','INSTALAR EN ESTE PC','secondary',instalar);
  add('enelR0693Desactivar','DESHABILITAR DESCARGA DIARIA · ESTE PC','danger',()=>ejecutar('desactivar'));
  add('enelR0693Estado','ESTADO DE ESTE PC','secondary',()=>ejecutar('estado'));
  const rot=qs('#enelRotate'),man=qs('#enelManual'),prog=qs('#enelPlan'),guide=qs('#enelGuide');
  if(rot){rot.textContent='ACTUALIZAR CLAVE DPAPI · ESTE PC';rot.onclick=()=>ejecutar('clave')}
  if(man){man.textContent='DESCARGA MANUAL · ESTE PC';man.onclick=()=>ejecutar('manual')}
  if(prog){prog.textContent='ACTIVAR DESCARGA DIARIA · ESTE PC';prog.onclick=()=>ejecutar('activar')}
  if(guide){guide.textContent='GUÍA DE INSTALACIÓN R069.3';guide.onclick=guia}
  buttons.style.gridTemplateColumns='repeat(3,minmax(0,1fr))';
  const notice=document.createElement('div');notice.className='enel-note';
  notice.textContent='R069.3 · CONTROL LOCAL POR PC. Instalación inicial: descargar y ejecutar instalador una vez por usuario Windows. El monitoreo ENEL en Sheets es remoto, pero activar/desactivar Scheduler se hace en el computador local. Sin control remoto del servidor todavía.';
  buttons.insertAdjacentElement('afterend',notice);
  const style=document.createElement('style');
  style.textContent='@media(max-width:1000px){#enelR069 .enel-actions{grid-template-columns:repeat(2,minmax(0,1fr))!important}}@media(max-width:650px){#enelR069 .enel-actions{grid-template-columns:1fr!important}}';
  document.head.appendChild(style);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
