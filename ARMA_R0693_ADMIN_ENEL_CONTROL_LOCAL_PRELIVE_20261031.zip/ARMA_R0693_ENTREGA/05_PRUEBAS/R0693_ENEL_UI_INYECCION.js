/* A.R.D.A.N. R069.3 - Panel ENEL en Administrar ARMA.
   Sin secretos. Acciones locales fijas. Backend R069.1 permanece intacto. */
(function(){
 'use strict';
 const paquete='ARMA_ENEL_R0693_INSTALADOR_PC.zip';
 const acciones={
  clave:{scheme:'arma-enel-r0693-clave://abrir',titulo:'ACTUALIZAR CLAVE ENEL · ESTE PC',descripcion:'Primero cambiar la clave en el portal oficial ENEL y probar el acceso. Después el agente local solicitará la credencial, sin enviarla a ARMA web. Solo actualiza DPAPI del usuario Windows actual.'},
  manual:{scheme:'arma-enel-r0693-manual://abrir',titulo:'DESCARGA MANUAL ENEL · ESTE PC',descripcion:'Ejecuta el verificador R061 y el ciclo local de descarga + ingesta. Requiere Node, Python, Playwright, receptor HMAC y credencial DPAPI correctamente configurados.'},
  activar:{scheme:'arma-enel-r0693-activar://abrir',titulo:'ACTIVAR AUTOMÁTICA · ESTE PC',descripcion:'Crea o habilita la tarea local ARMA_ENEL_R065_DIARIO a las 03:30 solo después de una descarga manual reciente OK. La primera creación solicita la contraseña de WINDOWS en una consola local. No cambia tareas en otros computadores.'},
  desactivar:{scheme:'arma-enel-r0693-desactivar://abrir',titulo:'DESHABILITAR AUTOMÁTICA · ESTE PC',descripcion:'Deshabilita futuras ejecuciones de la tarea diaria ENEL del computador donde está abierto ARMA. No detiene una descarga ya en marcha ni afecta otras tareas.'},
  estado:{scheme:'arma-enel-r0693-estado://abrir',titulo:'ESTADO DEL AGENTE · ESTE PC',descripcion:'Abre un diagnóstico local de identidad Windows, DPAPI, tarea programada y último resultado R061. No equivale al estado remoto del servidor.'}
 };
 const qs=(s)=>document.querySelector(s);
 async function autorizado(){
  if(typeof api!=='function'||typeof token!=='function'||!token())throw Error('INICIA SESIÓN EN MAIN');
  const j=await api('armaAdminBootstrap',{},45000);
  if(String(j.nivel||'').toUpperCase()!=='SUPER_ADMIN')throw Error('ACCESO EXCLUSIVO SUPER_ADMIN');
  return true;
 }
 async function dialogo(t,detalle,confirmar){
  if(typeof modal==='function')return modal(t,detalle,!!confirmar);
  return confirmar?window.confirm(t+'\n'+detalle):(window.alert(t+'\n'+detalle),true);
 }
 function abrirProtocolo(url){
  const link=document.createElement('a');link.href=url;link.style.display='none';
  document.body.appendChild(link);link.click();link.remove();
 }
 async function ejecutar(tipo){
  try{
   await autorizado();
   const a=acciones[tipo];if(!a)throw Error('ACCIÓN DESCONOCIDA');
   const si=await dialogo(a.titulo,a.descripcion+'\n\nRequiere instalar previamente el agente local R069.3 en ESTE PC y con el mismo usuario Windows del robot.\n¿ABRIR CONTROL LOCAL?',true);
   if(si)abrirProtocolo(a.scheme);
  }catch(e){await dialogo('ARMA ENEL · NO INICIADO',String(e.message||e),false)}
 }
 async function instalar(){
  try{
   await autorizado();
   const ok=await dialogo('INSTALAR ARMA ENEL · ESTE PC','El navegador descargará un archivo ZIP. Por restricciones de Windows, ninguna web puede instalar PowerShell o Task Scheduler silenciosamente.\n\nPASOS: 1) Extraer en DESCARGAS; 2) abrir la carpeta extraída; 3) ejecutar 01_INSTALAR_EN_ESTE_PC.cmd; 4) escribir INSTALAR en consola. El puente quedará registrado para el usuario Windows actual.\n\nLos archivos originales R047/R061 no se sobrescriben. ¿DESCARGAR INSTALADOR?',true);
   if(!ok)return;
   const probe=await fetch(paquete,{method:'HEAD',cache:'no-store'});
   if(!probe.ok)throw Error('ZIP NO PUBLICADO EN GITHUB PAGES: falta copiar '+paquete+' al repositorio y publicarlo.');
   const a=document.createElement('a');a.href=paquete;a.download=paquete;document.body.appendChild(a);a.click();a.remove();
  }catch(e){await dialogo('INSTALADOR NO DISPONIBLE',String(e.message||e),false)}
 }
 async function guia(){
  await dialogo('ENEL R069.3 · USO EN CUALQUIER PC','1. INSTALAR EN ESTE PC: descarga ZIP y exige una sola ejecución local de 01_INSTALAR_EN_ESTE_PC.cmd.\n2. Antes de usar descargas: configurar credenciales ENEL vía DPAPI, clave HMAC del receptor y dependencias Node/Python/Playwright EN ESTE usuario Windows.\n3. CAMBIAR CLAVE: primero cambiar y probar en portal ENEL; luego actualizar DPAPI desde la página.\n4. DESCARGA MANUAL: correr ciclo R061, confirmar recepción real en Sheets.\n5. ACTIVAR: crea o habilita tarea local, previa descarga OK.\n6. DESHABILITAR: inhabilita tarea local, preserva configuración.\n7. ESTADO: muestra información de ESTE PC.\nIMPORTANTE: Abrir esta página en PC distinto NO permite controlar un servidor remoto. Para eso se requiere un agente permanente en el servidor y una cola autenticada de órdenes por HTTPS saliente.',false);
 }
 function init(){
  const panel=qs('#enelR069'),buttons=qs('#enelR069 .enel-actions');
  if(!panel||!buttons||document.getElementById('enelR0693Instalar'))return;
  const add=(id,texto,cls,callback)=>{
   const b=document.createElement('button');b.type='button';b.id=id;b.className='btn '+cls;b.textContent=texto;
   b.onclick=callback;buttons.appendChild(b);
  };
  add('enelR0693Instalar','INSTALAR EN ESTE PC','secondary',instalar);
  add('enelR0693Desactivar','DESHABILITAR DESCARGA DIARIA · ESTE PC','danger',()=>ejecutar('desactivar'));
  add('enelR0693Estado','ESTADO DE ESTE PC','secondary',()=>ejecutar('estado'));
  const rot=qs('#enelRotate'),man=qs('#enelManual'),prog=qs('#enelPlan'),guide=qs('#enelGuide');
  if(rot){rot.textContent='ACTUALIZAR CLAVE DPAPI · ESTE PC';rot.onclick=()=>ejecutar('clave')}
  if(man){man.textContent='DESCARGA MANUAL · ESTE PC';man.onclick=()=>ejecutar('manual')}
  if(prog){prog.textContent='ACTIVAR DESCARGA DIARIA · ESTE PC';prog.onclick=()=>ejecutar('activar')}
  if(guide){guide.textContent='GUÍA DE INSTALACIÓN R069.3';guide.onclick=guia}
  buttons.style.gridTemplateColumns='repeat(3,minmax(0,1fr))';
  const notice=document.createElement('div');notice.className='enel-note';
  notice.textContent='R069.3 · CONTROL LOCAL POR PC. Instalación inicial: descargar y ejecutar instalador una vez por usuario Windows. El monitoreo ENEL en Sheets es remoto, pero activar/desactivar Scheduler se hace en el computador local. Sin control remoto del servidor todavía.';
  buttons.insertAdjacentElement('afterend',notice);
  const style=document.createElement('style');
  style.textContent='@media(max-width:1000px){#enelR069 .enel-actions{grid-template-columns:repeat(2,minmax(0,1fr))!important}}@media(max-width:650px){#enelR069 .enel-actions{grid-template-columns:1fr!important}}';
  document.head.appendChild(style);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
